package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.SettingsInputComponent
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AudioLevels
import com.example.data.DspSettings
import com.example.data.HardwareMicType
import com.example.data.MicDeviceStatus
import com.example.data.MicTestResult
import com.example.data.MicTestState
import com.example.ui.theme.ConsoleBackground
import com.example.ui.theme.ConsoleBorder
import com.example.ui.theme.ConsoleBorderBright
import com.example.ui.theme.ConsoleSurface
import com.example.ui.theme.ConsoleSurfaceElevated
import com.example.ui.theme.DangerRed
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.FieryOrange
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.SafeGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningYellow
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MicTestSystemBottomSheet(
    settings: DspSettings,
    testState: MicTestState,
    recordingProgress: Float,
    playbackProgress: Float,
    latestResult: MicTestResult?,
    liveLoopbackLevels: AudioLevels,
    isPlayingBoosted: Boolean,
    activeMicStatus: MicDeviceStatus,
    onStartVoiceRecordTest: (Int) -> Unit,
    onPlayVoiceTest: (Boolean) -> Unit,
    onStopVoiceTestPlayback: () -> Unit,
    onToggleLiveLoopback: () -> Unit,
    onSetBoostPercentage: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var selectedTestTab by remember { mutableStateOf(0) } // 0: Record & Hear Voice, 1: Live Sidetone Monitor

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = ConsoleBackground,
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 10.dp)
                    .width(40.dp)
                    .height(4.dp)
                    .clip(CircleShape)
                    .background(ConsoleBorderBright)
            )
        },
        modifier = Modifier.testTag("mic_test_bottom_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 1. Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(NeonCyan, ElectricViolet))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Hearing,
                            contentDescription = null,
                            tint = Color(0xFF030712),
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Column {
                        Text(
                            text = "MIC TEST & VOICE MONITOR",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            color = NeonCyan
                        )
                        Text(
                            text = "Instant Voice Playback • Clarity Benchmark",
                            fontSize = 10.5.sp,
                            color = TextSecondary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("close_mic_test_sheet_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = TextSecondary
                    )
                }
            }

            // Active Hardware Mic Pill Banner
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(ConsoleSurfaceElevated)
                    .border(1.dp, ConsoleBorder, RoundedCornerShape(10.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.SettingsInputComponent,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(15.dp)
                    )
                    Text(
                        text = "Testing Mic: ${activeMicStatus.name}",
                        color = TextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(SafeGreen.copy(alpha = 0.2f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "ACTIVE",
                        color = SafeGreen,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            // 2. Mode Tabs (Record & Hear Voice vs Live Real-Time Sidetone)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(ConsoleSurfaceElevated)
                    .border(1.dp, ConsoleBorder, RoundedCornerShape(10.dp))
                    .padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (selectedTestTab == 0) NeonCyan else Color.Transparent)
                        .clickable { selectedTestTab = 0 }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "🎙️ Record & Listen (A/B)",
                        color = if (selectedTestTab == 0) Color(0xFF030712) else TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (selectedTestTab == 1) ElectricViolet else Color.Transparent)
                        .clickable { selectedTestTab = 1 }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "🎧 Live Sidetone (Headset)",
                        color = if (selectedTestTab == 1) Color(0xFF030712) else TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            if (selectedTestTab == 0) {
                // Tab 1: Record 5s/10s voice sample & Instant Playback
                RecordAndHearVoiceSection(
                    testState = testState,
                    recordingProgress = recordingProgress,
                    playbackProgress = playbackProgress,
                    latestResult = latestResult,
                    isPlayingBoosted = isPlayingBoosted,
                    onStartTest = onStartVoiceRecordTest,
                    onPlay = onPlayVoiceTest,
                    onStopPlayback = onStopVoiceTestPlayback
                )
            } else {
                // Tab 2: Real-time Live Loopback Monitor
                LiveSidetoneMonitorSection(
                    testState = testState,
                    liveLevels = liveLoopbackLevels,
                    settings = settings,
                    onToggleLiveLoopback = onToggleLiveLoopback,
                    onSetBoost = onSetBoostPercentage
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

/**
 * Section 1: Record 5-second sample & Playback with A/B comparison
 */
@Composable
private fun RecordAndHearVoiceSection(
    testState: MicTestState,
    recordingProgress: Float,
    playbackProgress: Float,
    latestResult: MicTestResult?,
    isPlayingBoosted: Boolean,
    onStartTest: (Int) -> Unit,
    onPlay: (Boolean) -> Unit,
    onStopPlayback: () -> Unit
) {
    val isRecording = testState == MicTestState.RECORDING
    val isPlaying = testState == MicTestState.PLAYING

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Main Test Recording Control Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = ConsoleSurface),
            border = CardDefaults.outlinedCardBorder().copy(
                brush = Brush.horizontalGradient(
                    if (isRecording) listOf(NeonPink, FieryOrange)
                    else if (isPlaying) listOf(NeonCyan, ElectricViolet)
                    else listOf(ConsoleBorder, ConsoleBorder)
                )
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = when (testState) {
                        MicTestState.RECORDING -> "🔴 RECORDING VOICE SAMPLE... SPEAK NOW!"
                        MicTestState.PLAYING -> if (isPlayingBoosted) "🔊 PLAYING BOOSTED VOICE (+DSP)" else "🔈 PLAYING RAW MIC SAMPLE"
                        else -> if (latestResult != null) "✅ VOICE SAMPLE READY TO AUDITION" else "TAP BELOW TO TEST YOUR VOICE"
                    },
                    color = when (testState) {
                        MicTestState.RECORDING -> NeonPink
                        MicTestState.PLAYING -> NeonCyan
                        else -> TextPrimary
                    },
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp,
                    textAlign = TextAlign.Center
                )

                // Live Visualizer / Recording Progress Ring
                Box(
                    modifier = Modifier
                        .size(120.dp)
                        .clip(CircleShape)
                        .background(ConsoleSurfaceElevated)
                        .border(
                            2.dp,
                            if (isRecording) NeonPink else if (isPlaying) NeonCyan else ConsoleBorderBright,
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isRecording) {
                        val pulseTransition = rememberInfiniteTransition(label = "pulse")
                        val scale by pulseTransition.animateFloat(
                            initialValue = 0.92f,
                            targetValue = 1.08f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(400, easing = FastOutSlowInEasing),
                                repeatMode = RepeatMode.Reverse
                            ),
                            label = "pulseScale"
                        )
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Recording",
                            tint = NeonPink,
                            modifier = Modifier
                                .size(48.dp)
                                .scale(scale)
                        )
                    } else if (isPlaying) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Playing",
                            tint = NeonCyan,
                            modifier = Modifier.size(48.dp)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = "Mic Test",
                            tint = ElectricViolet,
                            modifier = Modifier.size(48.dp)
                        )
                    }
                }

                // Progress Bar
                if (isRecording) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        LinearProgressIndicator(
                            progress = { recordingProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = NeonPink,
                            trackColor = ConsoleSurfaceElevated
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Recording Voice...", color = TextSecondary, fontSize = 10.sp)
                            Text("${(recordingProgress * 100).toInt()}%", color = NeonPink, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                } else if (isPlaying) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        LinearProgressIndicator(
                            progress = { playbackProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = NeonCyan,
                            trackColor = ConsoleSurfaceElevated
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Listening to Voice...", color = TextSecondary, fontSize = 10.sp)
                            Text("${(playbackProgress * 100).toInt()}%", color = NeonCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Action Buttons for Recording
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { onStartTest(5) },
                        enabled = !isRecording,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonCyan,
                            contentColor = Color(0xFF030712)
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("record_5s_test_button")
                    ) {
                        Icon(imageVector = Icons.Default.Mic, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("RECORD 5s TEST", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = { onStartTest(10) },
                        enabled = !isRecording,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("record_10s_test_button")
                    ) {
                        Icon(imageVector = Icons.Default.Mic, contentDescription = null, tint = ElectricViolet, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("10s DEEP TEST", color = ElectricViolet, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Audition & A/B Comparison Card (Shows if a recording exists)
        if (latestResult != null) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = ConsoleSurface),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(listOf(NeonCyan.copy(alpha = 0.5f), ElectricViolet.copy(alpha = 0.5f)))
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Equalizer,
                                contentDescription = null,
                                tint = NeonCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "LISTEN TO YOUR VOICE (A/B COMPARISON)",
                                color = TextPrimary,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (isPlaying) {
                            IconButton(
                                onClick = onStopPlayback,
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Stop,
                                    contentDescription = "Stop",
                                    tint = DangerRed,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }

                    // Recorded Waveform Mini Bar
                    RecordedWaveformBar(
                        waveform = latestResult.recordedWaveform,
                        playbackProgress = if (isPlaying) playbackProgress else 0f
                    )

                    // A/B Playback Buttons (Boosted vs Raw)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onPlay(true) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isPlaying && isPlayingBoosted) SafeGreen else NeonCyan,
                                contentColor = Color(0xFF030712)
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .testTag("play_boosted_voice_button")
                        ) {
                            Icon(
                                imageVector = if (isPlaying && isPlayingBoosted) Icons.Default.VolumeUp else Icons.Default.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isPlaying && isPlayingBoosted) "PLAYING BOOSTED" else "🔊 PLAY BOOSTED",
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        OutlinedButton(
                            onClick = { onPlay(false) },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .testTag("play_raw_voice_button")
                        ) {
                            Icon(
                                imageVector = if (isPlaying && !isPlayingBoosted) Icons.Default.VolumeUp else Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = TextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isPlaying && !isPlayingBoosted) "PLAYING RAW" else "🔈 PLAY RAW MIC",
                                color = TextSecondary,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Acoustic Analytics Diagnostic Badges
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(ConsoleSurfaceElevated)
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Voice Clarity Index:",
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                            Text(
                                text = "${latestResult.clarityScore}% Crystal Clear",
                                color = if (latestResult.clarityScore >= 80) SafeGreen else WarningYellow,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Raw Mic Input", color = TextMuted, fontSize = 9.sp)
                                Text(
                                    String.format(Locale.US, "%.1f dBFS", latestResult.rawRmsDb),
                                    color = TextSecondary,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column {
                                Text("Amplified Output", color = TextMuted, fontSize = 9.sp)
                                Text(
                                    String.format(Locale.US, "%.1f dBFS", latestResult.boostedRmsDb),
                                    color = NeonCyan,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column {
                                Text("Signal-To-Noise", color = TextMuted, fontSize = 9.sp)
                                Text(
                                    String.format(Locale.US, "+%.1f dB", latestResult.snrDb),
                                    color = SafeGreen,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Verdict Banner
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF0C111E))
                                .padding(8.dp)
                        ) {
                            Text(
                                text = latestResult.evaluationVerdict,
                                color = TextPrimary,
                                fontSize = 10.sp,
                                lineHeight = 13.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Section 2: Real-time Live Sidetone Loopback Monitor (Listen while speaking)
 */
@Composable
private fun LiveSidetoneMonitorSection(
    testState: MicTestState,
    liveLevels: AudioLevels,
    settings: DspSettings,
    onToggleLiveLoopback: () -> Unit,
    onSetBoost: (Int) -> Unit
) {
    val isLiveMonitor = testState == MicTestState.LIVE_MONITOR

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Headset Advice Banner
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(ElectricViolet.copy(alpha = 0.12f))
                .border(1.dp, ElectricViolet.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Headphones,
                contentDescription = null,
                tint = ElectricViolet,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = "For zero-feedback voice monitoring, plug in wired headphones or use a Bluetooth headset while talking.",
                color = TextSecondary,
                fontSize = 10.5.sp,
                lineHeight = 14.sp
            )
        }

        // Live Sidetone Switch Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = ConsoleSurface),
            border = CardDefaults.outlinedCardBorder().copy(
                brush = Brush.horizontalGradient(
                    if (isLiveMonitor) listOf(SafeGreen, NeonCyan)
                    else listOf(ConsoleBorder, ConsoleBorder)
                )
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "REAL-TIME VOICE MONITOR",
                            color = if (isLiveMonitor) SafeGreen else TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isLiveMonitor) "Speaking in mic $\\rightarrow$ playing out to ear in real-time" else "Direct zero-latency audio loopback",
                            color = TextMuted,
                            fontSize = 10.sp
                        )
                    }

                    Switch(
                        checked = isLiveMonitor,
                        onCheckedChange = { onToggleLiveLoopback() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF030712),
                            checkedTrackColor = SafeGreen,
                            uncheckedThumbColor = TextMuted,
                            uncheckedTrackColor = ConsoleSurfaceElevated
                        ),
                        modifier = Modifier.testTag("toggle_live_monitor_switch")
                    )
                }

                // Live Meters & Waveform when monitor is active
                if (isLiveMonitor) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(ConsoleSurfaceElevated)
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "Live Voice Level:",
                                color = TextSecondary,
                                fontSize = 10.sp
                            )
                            Text(
                                String.format(Locale.US, "%.1f dBFS", liveLevels.outputRmsDb),
                                color = NeonCyan,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Live Level Bar
                        val levelNorm = ((liveLevels.outputRmsDb + 60f) / 60f).coerceIn(0f, 1f)
                        LinearProgressIndicator(
                            progress = { levelNorm },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = if (levelNorm > 0.85f) DangerRed else NeonCyan,
                            trackColor = Color(0xFF0C101D)
                        )
                    }
                }

                // Interactive Gain slider for Live Monitor testing
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Test Boost Multiplier:",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "+${settings.boostPercentage}%",
                            color = NeonCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Slider(
                        value = settings.boostPercentage.toFloat(),
                        onValueChange = { onSetBoost(it.roundToInt()) },
                        valueRange = 100f..1000f,
                        colors = SliderDefaults.colors(
                            thumbColor = NeonCyan,
                            activeTrackColor = NeonCyan,
                            inactiveTrackColor = ConsoleSurfaceElevated
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("test_gain_slider")
                    )
                }
            }
        }
    }
}

/**
 * Custom canvas showing recorded voice waveform bars with animated playback cursor
 */
@Composable
private fun RecordedWaveformBar(
    waveform: FloatArray,
    playbackProgress: Float,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(48.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF080C16))
            .padding(horizontal = 6.dp, vertical = 4.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val totalBars = waveform.size
            if (totalBars == 0) return@Canvas

            val barSpacing = 2.dp.toPx()
            val totalSpacing = barSpacing * (totalBars - 1)
            val barWidth = max(2f, (size.width - totalSpacing) / totalBars)
            val centerY = size.height / 2f
            val maxBarHeight = size.height * 0.85f

            for (i in 0 until totalBars) {
                val x = i * (barWidth + barSpacing)
                val amp = waveform[i].coerceIn(0.08f, 1f)
                val barH = max(4f, amp * maxBarHeight)

                val barProgress = i.toFloat() / totalBars.toFloat()
                val isPlayed = barProgress <= playbackProgress

                val barColor = if (isPlayed) SafeGreen else NeonCyan.copy(alpha = 0.5f)

                drawRoundRect(
                    color = barColor,
                    topLeft = Offset(x, centerY - barH / 2f),
                    size = Size(barWidth, barH),
                    cornerRadius = CornerRadius(2.dp.toPx())
                )
            }

            // Draw playback cursor
            if (playbackProgress in 0.01f..0.99f) {
                val cursorX = playbackProgress * size.width
                drawLine(
                    color = NeonPink,
                    start = Offset(cursorX, 0f),
                    end = Offset(cursorX, size.height),
                    strokeWidth = 2.dp.toPx()
                )
            }
        }
    }
}
