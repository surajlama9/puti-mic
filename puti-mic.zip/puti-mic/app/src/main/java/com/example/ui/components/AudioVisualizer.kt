package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ConsoleBorder
import com.example.ui.theme.ConsoleSurface
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import kotlin.math.sin

@Composable
fun AudioVisualizer(
    isLive: Boolean,
    isMuted: Boolean,
    waveform: FloatArray,
    frequencyBands: FloatArray,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(ConsoleSurface)
            .border(1.dp, ConsoleBorder, RoundedCornerShape(16.dp))
            .padding(12.dp)
            .testTag("audio_visualizer_box")
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "REAL-TIME SPECTRUM & OSCILLOSCOPE",
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )

                Text(
                    text = if (isLive && !isMuted) "44.1 kHz • DSP ACTIVE" else "STANDBY",
                    color = if (isLive && !isMuted) NeonCyan else TextMuted,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Canvas drawing both frequency bars and waveform overlay
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(80.dp)
                    .testTag("visualizer_canvas")
            ) {
                val width = size.width
                val height = size.height
                val midY = height / 2f

                // 1. Draw Subtle Grid Lines
                drawLine(
                    color = ConsoleBorder.copy(alpha = 0.5f),
                    start = Offset(0f, midY),
                    end = Offset(width, midY),
                    strokeWidth = 1f
                )
                drawLine(
                    color = ConsoleBorder.copy(alpha = 0.3f),
                    start = Offset(0f, height * 0.25f),
                    end = Offset(width, height * 0.25f),
                    strokeWidth = 0.5f
                )
                drawLine(
                    color = ConsoleBorder.copy(alpha = 0.3f),
                    start = Offset(0f, height * 0.75f),
                    end = Offset(width, height * 0.75f),
                    strokeWidth = 0.5f
                )

                // 2. Draw Frequency Bars in background
                val numBands = 16
                val totalSpacing = width * 0.2f
                val barWidth = (width - totalSpacing) / numBands
                val barGap = totalSpacing / (numBands + 1)

                val barGradient = Brush.verticalGradient(
                    listOf(
                        NeonPink,
                        ElectricViolet,
                        NeonCyan
                    )
                )

                for (i in 0 until numBands) {
                    val bandValue = if (isLive && !isMuted && i < frequencyBands.size) {
                        frequencyBands[i].coerceIn(0.04f, 1.0f)
                    } else {
                        0.03f
                    }
                    val barHeight = (height * 0.85f) * bandValue
                    val left = barGap + i * (barWidth + barGap)
                    val top = height - barHeight

                    drawRoundRect(
                        brush = barGradient,
                        topLeft = Offset(left, top),
                        size = Size(barWidth, barHeight),
                        cornerRadius = CornerRadius(4f, 4f),
                        alpha = if (isLive && !isMuted) 0.85f else 0.25f
                    )
                }

                // 3. Draw Oscilloscope Waveform Line
                val path = Path()
                val waveLength = waveform.size
                if (waveLength > 1) {
                    val stepX = width / (waveLength - 1)
                    for (k in 0 until waveLength) {
                        val sample = if (isLive && !isMuted) waveform[k] else 0f
                        val x = k * stepX
                        // Amplify wave amplitude for distinct visual presence
                        val y = midY - (sample * (height * 0.42f)).coerceIn(-midY + 4f, midY - 4f)
                        if (k == 0) {
                            path.moveTo(x, y)
                        } else {
                            val prevX = (k - 1) * stepX
                            val prevSample = if (isLive && !isMuted) waveform[k - 1] else 0f
                            val prevY = midY - (prevSample * (height * 0.42f)).coerceIn(-midY + 4f, midY - 4f)
                            // Smooth quadratic bezier curve between points
                            val cX = (prevX + x) / 2f
                            val cY = (prevY + y) / 2f
                            path.quadraticTo(prevX, prevY, cX, cY)
                        }
                    }

                    // Draw outer glow line
                    drawPath(
                        path = path,
                        color = NeonCyan.copy(alpha = if (isLive && !isMuted) 0.5f else 0.2f),
                        style = Stroke(width = 6f, cap = StrokeCap.Round)
                    )

                    // Draw crisp center wave
                    drawPath(
                        path = path,
                        color = if (isLive && !isMuted) Color.White else TextMuted,
                        style = Stroke(width = 2.2f, cap = StrokeCap.Round)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Frequency labels
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("SUB", color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text("LOW", color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text("MID", color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text("PRESENCE", color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text("HIGH AIR", color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}
