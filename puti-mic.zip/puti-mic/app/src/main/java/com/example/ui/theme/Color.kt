package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Puti Mic Futuristic Audio Console Color Palette
val NeonCyan = Color(0xFF00E5FF)
val NeonCyanGlow = Color(0x6600E5FF)
val ElectricViolet = Color(0xFF9D4EDD)
val NeonPurple = Color(0xFF7B2CBF)
val NeonPink = Color(0xFFFF007F)
val FieryOrange = Color(0xFFFF6D00)
val WarningYellow = Color(0xFFFFD166)
val SafeGreen = Color(0xFF06D6A0)
val DangerRed = Color(0xFFFF1744)

// Dark Console Surfaces
val ConsoleBackground = Color(0xFF070B14)
val ConsoleSurface = Color(0xFF0F172A)
val ConsoleSurfaceElevated = Color(0xFF17233D)
val ConsoleBorder = Color(0xFF1E2F52)
val ConsoleBorderBright = Color(0xFF2E4578)

// Meter Colors
val MeterGreen = Color(0xFF00E676)
val MeterYellow = Color(0xFFFFD600)
val MeterOrange = Color(0xFFFF9100)
val MeterRed = Color(0xFFFF1744)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val TextCyan = Color(0xFF67E8F9)
