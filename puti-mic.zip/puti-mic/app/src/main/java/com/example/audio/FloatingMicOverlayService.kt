package com.example.audio

import android.annotation.SuppressLint
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.example.MainActivity
import com.example.data.AudioLevels
import com.example.data.DspSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Floating Overlay Service that displays a sleek, draggable mini-controller over
 * other apps (such as Hapi, Masti, IMO, Discord) allowing on-the-fly boost, mute,
 * and live VU monitoring without leaving the active voice chat party room.
 */
class FloatingMicOverlayService : Service() {

    private val TAG = "FloatingMicOverlay"
    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private lateinit var audioEngine: MicAudioEngine

    private var tvBoost: TextView? = null
    private var tvStatus: TextView? = null
    private var btnMute: ImageView? = null
    private var vuIndicator: View? = null

    companion object {
        private val _isOverlayActive = MutableStateFlow(false)
        val isOverlayActive: StateFlow<Boolean> = _isOverlayActive.asStateFlow()

        fun startOverlay(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
                Log.w("FloatingMicOverlay", "Cannot draw overlays, permission missing")
                return
            }
            val intent = Intent(context, FloatingMicOverlayService::class.java)
            try {
                context.startService(intent)
            } catch (e: Exception) {
                Log.e("FloatingMicOverlay", "Failed to start overlay service: ${e.message}")
            }
        }

        fun stopOverlay(context: Context) {
            val intent = Intent(context, FloatingMicOverlayService::class.java)
            try {
                context.stopService(intent)
            } catch (e: Exception) {
                Log.e("FloatingMicOverlay", "Failed to stop overlay service: ${e.message}")
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        audioEngine = MicAmplifierService.getAudioEngine(this)
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        initFloatingLayout()
        observeAudioState()
        _isOverlayActive.value = true
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initFloatingLayout() {
        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 200
        }

        // Programmatically build sleek floating UI pill
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(24, 16, 24, 16)
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                setColor(0xEE0B0F19.toInt()) // Deep dark semi-translucent
                cornerRadius = 32f
                setStroke(2, 0xFF00E5FF.toInt()) // Neon Cyan border
            }
            elevation = 16f
        }

        // Drag handle & VU Dot
        vuIndicator = View(this).apply {
            val size = (16 * resources.displayMetrics.density).toInt()
            layoutParams = LinearLayout.LayoutParams(size, size).apply {
                marginEnd = 16
            }
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF00E5FF.toInt())
            }
        }
        container.addView(vuIndicator)

        // Text Info Column
        val textLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.START
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                marginEnd = 20
            }
        }

        tvBoost = TextView(this).apply {
            text = "${audioEngine.getCurrentSettings().boostPercentage}%"
            setTextColor(0xFF00E5FF.toInt())
            textSize = 13f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        textLayout.addView(tvBoost)

        tvStatus = TextView(this).apply {
            text = if (audioEngine.isLiveRunning.value) "LIVE MIC" else "STANDBY"
            setTextColor(0xFF94A3B8.toInt())
            textSize = 9f
        }
        textLayout.addView(tvStatus)
        container.addView(textLayout)

        // Minus Boost Button
        val btnMinus = createSmallButton("-50") {
            val curr = audioEngine.getCurrentSettings()
            val newBoost = (curr.boostPercentage - 50).coerceAtLeast(100)
            audioEngine.updateSettings(curr.copy(boostPercentage = newBoost))
            tvBoost?.text = "$newBoost%"
        }
        container.addView(btnMinus)

        // Plus Boost Button
        val btnPlus = createSmallButton("+50") {
            val curr = audioEngine.getCurrentSettings()
            val newBoost = (curr.boostPercentage + 50).coerceAtMost(10000)
            audioEngine.updateSettings(curr.copy(boostPercentage = newBoost))
            tvBoost?.text = "$newBoost%"
        }
        container.addView(btnPlus)

        // Mute Toggle Button
        btnMute = ImageView(this).apply {
            val size = (28 * resources.displayMetrics.density).toInt()
            layoutParams = LinearLayout.LayoutParams(size, size).apply {
                marginEnd = 12
            }
            setPadding(8, 8, 8, 8)
            setImageResource(android.R.drawable.ic_lock_silent_mode_off)
            setColorFilter(0xFFFFFFFF.toInt())
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF1E293B.toInt())
            }
            setOnClickListener {
                val curr = audioEngine.getCurrentSettings()
                val isNowMuted = !curr.isMuted
                audioEngine.updateSettings(curr.copy(isMuted = isNowMuted))
                updateMuteState(isNowMuted)
            }
        }
        container.addView(btnMute)

        // App Launch / Expand Icon
        val btnExpand = ImageView(this).apply {
            val size = (28 * resources.displayMetrics.density).toInt()
            layoutParams = LinearLayout.LayoutParams(size, size).apply {
                marginEnd = 8
            }
            setPadding(8, 8, 8, 8)
            setImageResource(android.R.drawable.ic_menu_crop)
            setColorFilter(0xFF00E5FF.toInt())
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF1E293B.toInt())
            }
            setOnClickListener {
                val intent = Intent(this@FloatingMicOverlayService, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                }
                startActivity(intent)
            }
        }
        container.addView(btnExpand)

        // Close Overlay Button
        val btnClose = ImageView(this).apply {
            val size = (24 * resources.displayMetrics.density).toInt()
            layoutParams = LinearLayout.LayoutParams(size, size)
            setPadding(6, 6, 6, 6)
            setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
            setColorFilter(0xFFEF4444.toInt())
            setOnClickListener {
                stopSelf()
            }
        }
        container.addView(btnClose)

        // Dragging gesture implementation
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        container.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    try {
                        windowManager?.updateViewLayout(container, params)
                    } catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }

        floatingView = container
        try {
            windowManager?.addView(container, params)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to add floating view: ${e.message}")
        }
    }

    private fun createSmallButton(text: String, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 10f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(0xFF00E5FF.toInt())
            gravity = Gravity.CENTER
            setPadding(16, 8, 16, 8)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                marginEnd = 12
            }
            layoutParams = params
            background = GradientDrawable().apply {
                cornerRadius = 14f
                setColor(0xFF1E293B.toInt())
                setStroke(1, 0xFF334155.toInt())
            }
            setOnClickListener { onClick() }
        }
    }

    private fun updateMuteState(isMuted: Boolean) {
        if (isMuted) {
            btnMute?.setImageResource(android.R.drawable.ic_lock_silent_mode)
            btnMute?.setColorFilter(0xFFEF4444.toInt())
            tvStatus?.text = "MUTED"
            tvStatus?.setTextColor(0xFFEF4444.toInt())
        } else {
            btnMute?.setImageResource(android.R.drawable.ic_lock_silent_mode_off)
            btnMute?.setColorFilter(0xFFFFFFFF.toInt())
            tvStatus?.text = if (audioEngine.isLiveRunning.value) "LIVE MIC" else "STANDBY"
            tvStatus?.setTextColor(0xFF94A3B8.toInt())
        }
    }

    private fun observeAudioState() {
        serviceScope.launch {
            audioEngine.isLiveRunning.collect { isRunning ->
                tvStatus?.text = if (isRunning) "LIVE MIC" else "STANDBY"
                tvStatus?.setTextColor(if (isRunning) 0xFF00E5FF.toInt() else 0xFF94A3B8.toInt())
            }
        }

        serviceScope.launch {
            audioEngine.audioLevels.collect { levels ->
                val peak = levels.outputPeak
                val drawable = vuIndicator?.background as? GradientDrawable
                val activeColor = when {
                    levels.isClipping -> 0xFFEF4444.toInt() // Red
                    peak > 0.6f -> 0xFFFF007A.toInt() // Neon Pink
                    peak > 0.2f -> 0xFF00E5FF.toInt() // Neon Cyan
                    else -> 0xFF10B981.toInt() // Safe Green
                }
                drawable?.setColor(activeColor)
            }
        }
    }

    override fun onDestroy() {
        _isOverlayActive.value = false
        floatingView?.let {
            try {
                windowManager?.removeView(it)
            } catch (_: Exception) {}
        }
        floatingView = null
        serviceScope.cancel()
        super.onDestroy()
    }
}
