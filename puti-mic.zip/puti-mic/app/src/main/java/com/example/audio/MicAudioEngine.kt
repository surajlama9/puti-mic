package com.example.audio

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.os.Process
import android.util.Log
import com.example.data.AudioFocusPolicy
import com.example.data.AudioInputSource
import com.example.data.AudioLevels
import com.example.data.DspSettings
import com.example.data.HardwareMicType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

class MicAudioEngine(private val context: Context) {
    private val TAG = "MicAudioEngine"

    private val sampleRate = 44100
    private val channelConfigIn = AudioFormat.CHANNEL_IN_MONO
    private val channelConfigOut = AudioFormat.CHANNEL_OUT_MONO
    private val audioFormat = AudioFormat.ENCODING_PCM_16BIT

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var audioRouter: AudioRouter? = null

    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var recordThread: Thread? = null

    @Volatile
    private var isRecording = false

    private var echoCanceler: AcousticEchoCanceler? = null
    private var noiseSuppressor: NoiseSuppressor? = null
    private var agc: AutomaticGainControl? = null

    // DSP components
    private val bassFilter = BiquadFilter()
    private val trebleFilter = BiquadFilter()
    private val vocalPresenceFilter = BiquadFilter()
    private val highPassFilter = BiquadFilter()
    private val noiseGate = NoiseGate(sampleRate = sampleRate.toFloat())
    private val feedbackSuppressor = FeedbackSuppressor(sampleRate = sampleRate.toFloat())

    // Live Audio Levels & Waveform
    private val _audioLevels = MutableStateFlow(AudioLevels())
    val audioLevels: StateFlow<AudioLevels> = _audioLevels.asStateFlow()

    private val _isLiveRunning = MutableStateFlow(false)
    val isLiveRunning: StateFlow<Boolean> = _isLiveRunning.asStateFlow()

    @Volatile
    private var currentSettings = DspSettings()

    @Volatile
    private var focusDuckingMultiplier = 1.0f

    private var audioFocusRequest: AudioFocusRequest? = null

    private val audioFocusChangeListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
        when (focusChange) {
            AudioManager.AUDIOFOCUS_LOSS -> {
                if (currentSettings.audioFocusPolicy == AudioFocusPolicy.STRICT) {
                    stop()
                }
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                if (currentSettings.audioFocusPolicy == AudioFocusPolicy.DUCK_ON_LOSS) {
                    focusDuckingMultiplier = 0.5f
                } else {
                    focusDuckingMultiplier = 1.0f
                }
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                if (currentSettings.audioFocusPolicy == AudioFocusPolicy.STRICT) {
                    focusDuckingMultiplier = 0f
                }
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                focusDuckingMultiplier = 1.0f
            }
        }
    }

    fun setAudioRouter(router: AudioRouter) {
        this.audioRouter = router
    }

    fun getCurrentSettings(): DspSettings = currentSettings

    init {
        updateFilters(currentSettings)
    }

    fun updateSettings(settings: DspSettings) {
        val oldSettings = currentSettings
        currentSettings = settings

        if (oldSettings.bassGainDb != settings.bassGainDb ||
            oldSettings.trebleGainDb != settings.trebleGainDb ||
            oldSettings.voiceClarityEnabled != settings.voiceClarityEnabled
        ) {
            updateFilters(settings)
        }

        // Hardware effect toggles
        try {
            echoCanceler?.enabled = settings.echoCancellationEnabled
            noiseSuppressor?.enabled = settings.noiseReductionEnabled
            agc?.enabled = settings.autoGainControl
        } catch (e: Exception) {
            Log.w(TAG, "Failed to toggle hardware audio effect: ${e.message}")
        }

        // Apply hardware mic device preference if changed
        if (oldSettings.hardwareMicType != settings.hardwareMicType) {
            audioRouter?.setHardwareMicType(settings.hardwareMicType)
            applyInputDeviceRouting(settings.hardwareMicType)
        }

        // If audio input source changed while running, restart audio capture
        if (isRecording && (oldSettings.audioInputSource != settings.audioInputSource || oldSettings.hardwareMicType != settings.hardwareMicType)) {
            restartAudioEngine()
        }
    }

    private fun applyInputDeviceRouting(micType: HardwareMicType) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && audioRecord != null) {
            val prefDevice = audioRouter?.getPreferredInputDevice(micType)
            if (prefDevice != null) {
                try {
                    audioRecord?.preferredDevice = prefDevice
                    Log.d(TAG, "Successfully set preferred audio input device: ${prefDevice.productName}")
                } catch (e: Exception) {
                    Log.w(TAG, "Could not set preferredDevice: ${e.message}")
                }
            }
        }
    }

    private fun updateFilters(settings: DspSettings) {
        bassFilter.setLowShelf(sampleRate.toFloat(), 180f, settings.bassGainDb)
        trebleFilter.setHighShelf(sampleRate.toFloat(), 5000f, settings.trebleGainDb)
        vocalPresenceFilter.setPeakingEq(sampleRate.toFloat(), 2800f, if (settings.voiceClarityEnabled) 6.0f else 0.0f, 1.2f)
        highPassFilter.setHighPass(sampleRate.toFloat(), 80f)
    }

    private fun requestAudioFocus() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val playbackAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()

                audioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(playbackAttributes)
                    .setAcceptsDelayedFocusGain(true)
                    .setOnAudioFocusChangeListener(audioFocusChangeListener)
                    .build()

                audioManager.requestAudioFocus(audioFocusRequest!!)
            } else {
                @Suppress("DEPRECATION")
                audioManager.requestAudioFocus(
                    audioFocusChangeListener,
                    AudioManager.STREAM_MUSIC,
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
                )
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to request audio focus: ${e.message}")
        }
    }

    private fun abandonAudioFocus() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioFocusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
            } else {
                @Suppress("DEPRECATION")
                audioManager.abandonAudioFocus(audioFocusChangeListener)
            }
        } catch (_: Exception) {}
    }

    private fun restartAudioEngine() {
        Thread {
            stop()
            try {
                Thread.sleep(100)
            } catch (_: Exception) {}
            start()
        }.start()
    }

    @SuppressLint("MissingPermission")
    fun start() {
        if (isRecording) return

        try {
            requestAudioFocus()

            // Prepare hardware mic routing
            audioRouter?.applyMicRouting(currentSettings.hardwareMicType)

            val minRecordBufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfigIn, audioFormat)
            val minTrackBufferSize = AudioTrack.getMinBufferSize(sampleRate, channelConfigOut, audioFormat)

            val recordBufferSize = max(minRecordBufferSize * 2, 2048)
            val trackBufferSize = max(minTrackBufferSize * 2, 2048)

            // Low-latency AudioRecord setup with configured source
            val audioSource = currentSettings.audioInputSource.mediaRecorderSource
            var record: AudioRecord? = null

            try {
                record = AudioRecord(
                    audioSource,
                    sampleRate,
                    channelConfigIn,
                    audioFormat,
                    recordBufferSize
                )
            } catch (e: Exception) {
                Log.w(TAG, "Failed to init AudioRecord with $audioSource, falling back to MIC: ${e.message}")
            }

            if (record == null || record.state != AudioRecord.STATE_INITIALIZED) {
                record?.release()
                // Fallback to standard MIC
                record = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    sampleRate,
                    channelConfigIn,
                    audioFormat,
                    recordBufferSize
                )
            }

            if (record.state != AudioRecord.STATE_INITIALIZED) {
                Log.e(TAG, "AudioRecord fallback initialization failed")
                record.release()
                return
            }

            audioRecord = record
            val audioSessionId = audioRecord!!.audioSessionId

            // Set preferred input hardware device (Bluetooth / Wired / Built-in)
            applyInputDeviceRouting(currentSettings.hardwareMicType)

            // Hardware DSP effects setup
            if (AcousticEchoCanceler.isAvailable()) {
                try {
                    echoCanceler = AcousticEchoCanceler.create(audioSessionId)?.apply {
                        enabled = currentSettings.echoCancellationEnabled
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "AEC setup failed: ${e.message}")
                }
            }

            if (NoiseSuppressor.isAvailable()) {
                try {
                    noiseSuppressor = NoiseSuppressor.create(audioSessionId)?.apply {
                        enabled = currentSettings.noiseReductionEnabled
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "NoiseSuppressor setup failed: ${e.message}")
                }
            }

            if (AutomaticGainControl.isAvailable()) {
                try {
                    agc = AutomaticGainControl.create(audioSessionId)?.apply {
                        enabled = currentSettings.autoGainControl
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "AGC setup failed: ${e.message}")
                }
            }

            // Low-latency AudioTrack setup
            val audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .setFlags(AudioAttributes.FLAG_LOW_LATENCY)
                .build()

            val audioFormatSpec = AudioFormat.Builder()
                .setEncoding(audioFormat)
                .setSampleRate(sampleRate)
                .setChannelMask(channelConfigOut)
                .build()

            audioTrack = AudioTrack(
                audioAttributes,
                audioFormatSpec,
                trackBufferSize,
                AudioTrack.MODE_STREAM,
                AudioManager.AUDIO_SESSION_ID_GENERATE
            )

            if (audioTrack?.state != AudioTrack.STATE_INITIALIZED) {
                Log.e(TAG, "AudioTrack initialization failed")
                stop()
                return
            }

            audioRecord?.startRecording()
            audioTrack?.play()
            isRecording = true
            _isLiveRunning.value = true

            bassFilter.reset()
            trebleFilter.reset()
            vocalPresenceFilter.reset()
            highPassFilter.reset()
            noiseGate.reset()
            feedbackSuppressor.reset()

            val processChunkSize = 256 // Small buffer chunk for ultra low latency (~5.8ms)
            recordThread = Thread {
                Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
                processAudioLoop(processChunkSize)
            }.apply {
                name = "PutiMicDspThread"
                start()
            }

        } catch (e: Exception) {
            Log.e(TAG, "Error starting Puti Mic audio engine: ${e.message}", e)
            stop()
        }
    }

    private fun processAudioLoop(chunkSize: Int) {
        val inputShortBuffer = ShortArray(chunkSize)
        val outputShortBuffer = ShortArray(chunkSize)
        val waveformVisualizer = FloatArray(32)
        val frequencyBands = FloatArray(16)

        var frameCounter = 0

        while (isRecording && audioRecord != null && audioTrack != null) {
            val shortsRead = audioRecord!!.read(inputShortBuffer, 0, chunkSize)
            if (shortsRead <= 0) continue

            val settings = currentSettings
            val isMuted = settings.isMuted
            val boostPercent = settings.boostPercentage

            // Digital Gain Multiplier: 100% = 1.0, 10,000% = 100.0
            var digitalGain = (boostPercent / 100.0f) * focusDuckingMultiplier
            if (settings.isSpeakerBoostEnabled) {
                digitalGain *= 1.414f // Additional +3dB expansion
            }

            var inSumSquares = 0.0
            var outSumSquares = 0.0
            var inPeak = 0.0f
            var outPeak = 0.0f
            var isClipping = false

            for (i in 0 until shortsRead) {
                val rawNormalized = inputShortBuffer[i] / 32768.0f
                inSumSquares += (rawNormalized * rawNormalized).toDouble()
                inPeak = max(inPeak, abs(rawNormalized))

                if (isMuted) {
                    outputShortBuffer[i] = 0
                    continue
                }

                var processed = rawNormalized

                // 1. High Pass filter to remove low rumble (< 80Hz)
                processed = highPassFilter.process(processed)

                // 2. Noise Gate
                if (settings.noiseReductionEnabled) {
                    processed = noiseGate.process(processed)
                }

                // 3. Voice Clarity / Vocal Presence EQ (2.8kHz)
                if (settings.voiceClarityEnabled) {
                    processed = vocalPresenceFilter.process(processed)
                }

                // 4. Bass & Treble tone EQ
                if (settings.bassGainDb != 0f) {
                    processed = bassFilter.process(processed)
                }
                if (settings.trebleGainDb != 0f) {
                    processed = trebleFilter.process(processed)
                }

                // 5. Anti-Feedback Suppression
                if (settings.feedbackSuppressionEnabled) {
                    processed = feedbackSuppressor.process(processed)
                }

                // 6. Digital Pre-Amplification Gain
                processed *= digitalGain

                // 7. Studio Soft-Knee Saturation & Limiter
                if (abs(processed) > 0.98f) {
                    isClipping = true
                }
                val limited = AudioLimiter.applySoftLimiter(processed, settings.limiterEnabled)

                outSumSquares += (limited * limited).toDouble()
                outPeak = max(outPeak, abs(limited))

                // Convert back to PCM 16-bit
                val pcmSample = (limited * 32767.0f).toInt().coerceIn(-32768, 32767)
                outputShortBuffer[i] = pcmSample.toShort()
            }

            // Write processed audio to output track
            audioTrack?.write(outputShortBuffer, 0, shortsRead)

            // Update UI level meters periodically (~60 FPS)
            frameCounter++
            if (frameCounter % 6 == 0) {
                val inRms = sqrt(inSumSquares / shortsRead).toFloat()
                val outRms = sqrt(outSumSquares / shortsRead).toFloat()

                val inDb = if (inRms > 0.0001f) (20.0f * log10(inRms)).coerceIn(-60.0f, 0.0f) else -60.0f
                val outDb = if (outRms > 0.0001f) (20.0f * log10(outRms)).coerceIn(-60.0f, 6.0f) else -60.0f

                // Build waveform downsampled points
                val step = max(1, shortsRead / 32)
                for (k in 0 until 32) {
                    val idx = min(k * step, shortsRead - 1)
                    waveformVisualizer[k] = if (isMuted) 0f else outputShortBuffer[idx] / 32768.0f
                }

                // Approximate spectral distribution for frequency bars
                val baseEnergy = if (isMuted) 0f else outPeak
                for (b in 0 until 16) {
                    val bandPhase = (frameCounter * 0.15f + b * 0.4f)
                    val pseudoHarmonic = abs(sin(bandPhase)) * 0.5f + 0.5f
                    val falloff = 1.0f - (b * 0.035f)
                    frequencyBands[b] = (baseEnergy * pseudoHarmonic * falloff).coerceIn(0.02f, 1.0f)
                }

                _audioLevels.value = AudioLevels(
                    inputRmsDb = inDb,
                    inputPeak = inPeak,
                    outputRmsDb = outDb,
                    outputPeak = outPeak,
                    isClipping = isClipping,
                    waveform = waveformVisualizer.copyOf(),
                    frequencyBands = frequencyBands.copyOf()
                )
            }
        }
    }

    fun stop() {
        isRecording = false
        _isLiveRunning.value = false

        abandonAudioFocus()

        try {
            recordThread?.join(500)
        } catch (_: Exception) {}
        recordThread = null

        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (e: Exception) {
            Log.w(TAG, "Error releasing AudioRecord: ${e.message}")
        }
        audioRecord = null

        try {
            audioTrack?.stop()
            audioTrack?.release()
        } catch (e: Exception) {
            Log.w(TAG, "Error releasing AudioTrack: ${e.message}")
        }
        audioTrack = null

        try {
            echoCanceler?.release()
            echoCanceler = null
            noiseSuppressor?.release()
            noiseSuppressor = null
            agc?.release()
            agc = null
        } catch (_: Exception) {}

        // Reset levels
        _audioLevels.value = AudioLevels()
    }
}
