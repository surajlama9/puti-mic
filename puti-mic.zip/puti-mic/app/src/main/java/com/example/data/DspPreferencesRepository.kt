package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "puti_mic_dsp_preferences")

/**
 * Repository responsible for persisting DSP and Voice Chat settings using Jetpack DataStore Preferences.
 */
class DspPreferencesRepository(private val context: Context) {

    private object PreferencesKeys {
        val BOOST_PERCENTAGE = intPreferencesKey("boost_percentage")
        val IS_SPEAKER_BOOST_ENABLED = booleanPreferencesKey("is_speaker_boost_enabled")
        val NOISE_REDUCTION_ENABLED = booleanPreferencesKey("noise_reduction_enabled")
        val ECHO_CANCELLATION_ENABLED = booleanPreferencesKey("echo_cancellation_enabled")
        val FEEDBACK_SUPPRESSION_ENABLED = booleanPreferencesKey("feedback_suppression_enabled")
        val VOICE_CLARITY_ENABLED = booleanPreferencesKey("voice_clarity_enabled")
        val LOW_LATENCY_MODE = booleanPreferencesKey("low_latency_mode")
        val AUTO_GAIN_CONTROL = booleanPreferencesKey("auto_gain_control")
        val LIMITER_ENABLED = booleanPreferencesKey("limiter_enabled")
        val BASS_GAIN_DB = floatPreferencesKey("bass_gain_db")
        val TREBLE_GAIN_DB = floatPreferencesKey("treble_gain_db")
        val AUDIO_INPUT_SOURCE = stringPreferencesKey("audio_input_source")
        val AUDIO_FOCUS_POLICY = stringPreferencesKey("audio_focus_policy")
        val ACTIVE_PROFILE_ID = stringPreferencesKey("active_profile_id")
        val FLOATING_OVERLAY_ENABLED = booleanPreferencesKey("floating_overlay_enabled")
        val HARDWARE_MIC_TYPE = stringPreferencesKey("hardware_mic_type")
    }

    val dspSettingsFlow: Flow<DspSettings> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { preferences ->
            val sourceName = preferences[PreferencesKeys.AUDIO_INPUT_SOURCE] ?: AudioInputSource.VOICE_COMMUNICATION.name
            val inputSource = try {
                AudioInputSource.valueOf(sourceName)
            } catch (_: Exception) {
                AudioInputSource.VOICE_COMMUNICATION
            }

            val focusPolicyName = preferences[PreferencesKeys.AUDIO_FOCUS_POLICY] ?: AudioFocusPolicy.IGNORE_FOCUS_LOSS.name
            val focusPolicy = try {
                AudioFocusPolicy.valueOf(focusPolicyName)
            } catch (_: Exception) {
                AudioFocusPolicy.IGNORE_FOCUS_LOSS
            }

            val micTypeName = preferences[PreferencesKeys.HARDWARE_MIC_TYPE] ?: HardwareMicType.AUTO.name
            val hardwareMicType = try {
                HardwareMicType.valueOf(micTypeName)
            } catch (_: Exception) {
                HardwareMicType.AUTO
            }

            DspSettings(
                boostPercentage = preferences[PreferencesKeys.BOOST_PERCENTAGE] ?: 150,
                isMuted = false, // Always start unmuted on launch for safety
                isSpeakerBoostEnabled = preferences[PreferencesKeys.IS_SPEAKER_BOOST_ENABLED] ?: false,
                noiseReductionEnabled = preferences[PreferencesKeys.NOISE_REDUCTION_ENABLED] ?: true,
                echoCancellationEnabled = preferences[PreferencesKeys.ECHO_CANCELLATION_ENABLED] ?: true,
                feedbackSuppressionEnabled = preferences[PreferencesKeys.FEEDBACK_SUPPRESSION_ENABLED] ?: true,
                voiceClarityEnabled = preferences[PreferencesKeys.VOICE_CLARITY_ENABLED] ?: true,
                lowLatencyMode = preferences[PreferencesKeys.LOW_LATENCY_MODE] ?: true,
                autoGainControl = preferences[PreferencesKeys.AUTO_GAIN_CONTROL] ?: false,
                limiterEnabled = preferences[PreferencesKeys.LIMITER_ENABLED] ?: true,
                bassGainDb = preferences[PreferencesKeys.BASS_GAIN_DB] ?: 0f,
                trebleGainDb = preferences[PreferencesKeys.TREBLE_GAIN_DB] ?: 0f,
                audioInputSource = inputSource,
                audioFocusPolicy = focusPolicy,
                activeProfileId = preferences[PreferencesKeys.ACTIVE_PROFILE_ID] ?: "hapi",
                floatingOverlayEnabled = preferences[PreferencesKeys.FLOATING_OVERLAY_ENABLED] ?: false,
                hardwareMicType = hardwareMicType
            )
        }

    suspend fun saveDspSettings(settings: DspSettings) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.BOOST_PERCENTAGE] = settings.boostPercentage
            preferences[PreferencesKeys.IS_SPEAKER_BOOST_ENABLED] = settings.isSpeakerBoostEnabled
            preferences[PreferencesKeys.NOISE_REDUCTION_ENABLED] = settings.noiseReductionEnabled
            preferences[PreferencesKeys.ECHO_CANCELLATION_ENABLED] = settings.echoCancellationEnabled
            preferences[PreferencesKeys.FEEDBACK_SUPPRESSION_ENABLED] = settings.feedbackSuppressionEnabled
            preferences[PreferencesKeys.VOICE_CLARITY_ENABLED] = settings.voiceClarityEnabled
            preferences[PreferencesKeys.LOW_LATENCY_MODE] = settings.lowLatencyMode
            preferences[PreferencesKeys.AUTO_GAIN_CONTROL] = settings.autoGainControl
            preferences[PreferencesKeys.LIMITER_ENABLED] = settings.limiterEnabled
            preferences[PreferencesKeys.BASS_GAIN_DB] = settings.bassGainDb
            preferences[PreferencesKeys.TREBLE_GAIN_DB] = settings.trebleGainDb
            preferences[PreferencesKeys.AUDIO_INPUT_SOURCE] = settings.audioInputSource.name
            preferences[PreferencesKeys.AUDIO_FOCUS_POLICY] = settings.audioFocusPolicy.name
            preferences[PreferencesKeys.ACTIVE_PROFILE_ID] = settings.activeProfileId
            preferences[PreferencesKeys.FLOATING_OVERLAY_ENABLED] = settings.floatingOverlayEnabled
            preferences[PreferencesKeys.HARDWARE_MIC_TYPE] = settings.hardwareMicType.name
        }
    }

    suspend fun resetDspToDefaults() {
        saveDspSettings(DspSettings())
    }
}
