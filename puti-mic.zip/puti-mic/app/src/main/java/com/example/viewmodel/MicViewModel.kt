package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioRouter
import com.example.audio.FloatingMicOverlayService
import com.example.audio.MicAmplifierService
import com.example.audio.MicAudioEngine
import com.example.audio.MicTestEngine
import com.example.data.AudioFocusPolicy
import com.example.data.AudioInputSource
import com.example.data.AudioLevels
import com.example.data.AudioRoute
import com.example.data.BoostMode
import com.example.data.DspPreferencesRepository
import com.example.data.DspSettings
import com.example.data.HardwareMicType
import com.example.data.MicDeviceStatus
import com.example.data.MicTestResult
import com.example.data.MicTestState
import com.example.data.VoiceChatProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MicViewModel(application: Application) : AndroidViewModel(application) {

    private val audioRouter = AudioRouter(application)
    private val audioEngine: MicAudioEngine = MicAmplifierService.getAudioEngine(application).apply {
        setAudioRouter(audioRouter)
    }
    private val micTestEngine = MicTestEngine(application, audioRouter)
    private val dspPreferencesRepository = DspPreferencesRepository(application)

    val isLiveRunning: StateFlow<Boolean> = audioEngine.isLiveRunning
    val audioLevels: StateFlow<AudioLevels> = audioEngine.audioLevels
    val currentRoute: StateFlow<AudioRoute> = audioRouter.currentRoute
    val availableRoutes: StateFlow<List<AudioRoute>> = audioRouter.availableRoutes
    val isOverlayActive: StateFlow<Boolean> = FloatingMicOverlayService.isOverlayActive

    // Hardware Mic Input state (All-In-One, Device, Bluetooth, Wired)
    val availableMicInputs: StateFlow<List<MicDeviceStatus>> = audioRouter.availableMicInputs
    val activeMicStatus: StateFlow<MicDeviceStatus> = audioRouter.activeMicStatus
    val selectedMicType: StateFlow<HardwareMicType> = audioRouter.selectedMicType

    // Microphone Test System & Voice Listening State
    val testState: StateFlow<MicTestState> = micTestEngine.testState
    val recordingProgress: StateFlow<Float> = micTestEngine.recordingProgress
    val playbackProgress: StateFlow<Float> = micTestEngine.playbackProgress
    val latestTestResult: StateFlow<MicTestResult?> = micTestEngine.latestTestResult
    val liveLoopbackLevels: StateFlow<AudioLevels> = micTestEngine.liveLoopbackLevels
    val isPlayingBoosted: StateFlow<Boolean> = micTestEngine.isPlayingBoosted

    private val _showMicTestModal = MutableStateFlow(false)
    val showMicTestModal: StateFlow<Boolean> = _showMicTestModal.asStateFlow()

    private val _settings = MutableStateFlow(DspSettings())
    val settings: StateFlow<DspSettings> = _settings.asStateFlow()

    val currentBoostMode: StateFlow<BoostMode> = _settings.map {
        BoostMode.fromPercentage(it.boostPercentage)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, BoostMode.NORMAL)

    val currentVoiceProfile: StateFlow<VoiceChatProfile> = _settings.map {
        VoiceChatProfile.fromId(it.activeProfileId)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, VoiceChatProfile.HAPI)

    private val _warningTargetMode = MutableStateFlow<BoostMode?>(null)
    val warningTargetMode: StateFlow<BoostMode?> = _warningTargetMode.asStateFlow()

    private val _showDisclaimerDialog = MutableStateFlow(false)
    val showDisclaimerDialog: StateFlow<Boolean> = _showDisclaimerDialog.asStateFlow()

    private val _showVoiceChatHub = MutableStateFlow(false)
    val showVoiceChatHub: StateFlow<Boolean> = _showVoiceChatHub.asStateFlow()

    private val _showMicSelectorDialog = MutableStateFlow(false)
    val showMicSelectorDialog: StateFlow<Boolean> = _showMicSelectorDialog.asStateFlow()

    private val _hasPermission = MutableStateFlow(false)
    val hasPermission: StateFlow<Boolean> = _hasPermission.asStateFlow()

    private val _showPermissionRationale = MutableStateFlow(false)
    val showPermissionRationale: StateFlow<Boolean> = _showPermissionRationale.asStateFlow()

    private val _isPermanentlyDenied = MutableStateFlow(false)
    val isPermanentlyDenied: StateFlow<Boolean> = _isPermanentlyDenied.asStateFlow()

    private val _showOverlayPermissionDialog = MutableStateFlow(false)
    val showOverlayPermissionDialog: StateFlow<Boolean> = _showOverlayPermissionDialog.asStateFlow()

    init {
        // Load persisted DSP preferences from DataStore
        viewModelScope.launch {
            try {
                val savedSettings = dspPreferencesRepository.dspSettingsFlow.first()
                _settings.value = savedSettings
                audioRouter.setHardwareMicType(savedSettings.hardwareMicType)
                audioEngine.updateSettings(savedSettings)
            } catch (_: Exception) {
                audioEngine.updateSettings(_settings.value)
            }
        }
    }

    fun setPermissionGranted(granted: Boolean) {
        _hasPermission.value = granted
        if (granted) {
            _showPermissionRationale.value = false
        }
    }

    fun showRationale(permanentlyDenied: Boolean = false) {
        _isPermanentlyDenied.value = permanentlyDenied
        _showPermissionRationale.value = true
    }

    fun dismissRationale() {
        _showPermissionRationale.value = false
    }

    fun toggleMic() {
        if (isLiveRunning.value) {
            stopMic()
        } else {
            startMic()
        }
    }

    fun startMic() {
        if (!_hasPermission.value) return
        audioEngine.updateSettings(_settings.value)
        MicAmplifierService.startService(
            getApplication(),
            _settings.value.boostPercentage
        )
    }

    fun stopMic() {
        MicAmplifierService.stopService(getApplication())
    }

    fun toggleMute() {
        val newMuted = !_settings.value.isMuted
        _settings.value = _settings.value.copy(isMuted = newMuted)
        audioEngine.updateSettings(_settings.value)
        notifyServiceSettingsChanged()
    }

    fun toggleSpeakerBoost() {
        val newSpeakerBoost = !_settings.value.isSpeakerBoostEnabled
        _settings.value = _settings.value.copy(isSpeakerBoostEnabled = newSpeakerBoost)
        audioEngine.updateSettings(_settings.value)
        persistDspSettings()
    }

    fun selectBoostMode(mode: BoostMode) {
        if (mode.requiresWarning) {
            _warningTargetMode.value = mode
        } else {
            setBoostPercentage(mode.defaultPercentage)
        }
    }

    fun confirmWarningMode() {
        _warningTargetMode.value?.let { mode ->
            setBoostPercentage(mode.defaultPercentage)
        }
        _warningTargetMode.value = null
    }

    fun dismissWarningDialog() {
        _warningTargetMode.value = null
    }

    fun setBoostPercentage(percentage: Int) {
        val clamped = percentage.coerceIn(100, 10000)
        _settings.value = _settings.value.copy(boostPercentage = clamped)
        audioEngine.updateSettings(_settings.value)
        persistDspSettings()
        notifyServiceSettingsChanged()
    }

    fun emergencyReset() {
        _settings.value = _settings.value.copy(
            boostPercentage = 100,
            isMuted = false,
            isSpeakerBoostEnabled = false,
            bassGainDb = 0f,
            trebleGainDb = 0f,
            limiterEnabled = true
        )
        audioEngine.updateSettings(_settings.value)
        persistDspSettings()
        notifyServiceSettingsChanged()
    }

    fun updateDsp(transform: (DspSettings) -> DspSettings) {
        _settings.value = transform(_settings.value)
        audioEngine.updateSettings(_settings.value)
        persistDspSettings()
    }

    fun resetDspToDefaults() {
        val defaultSettings = DspSettings()
        _settings.value = defaultSettings
        audioRouter.setHardwareMicType(defaultSettings.hardwareMicType)
        audioEngine.updateSettings(defaultSettings)
        persistDspSettings()
    }

    fun applyVoiceChatProfile(profile: VoiceChatProfile) {
        _settings.value = _settings.value.copy(
            activeProfileId = profile.id,
            boostPercentage = profile.recommendedBoost,
            audioInputSource = profile.recommendedSource,
            echoCancellationEnabled = profile.echoCancellation,
            noiseReductionEnabled = profile.noiseReduction,
            voiceClarityEnabled = profile.voiceClarity,
            feedbackSuppressionEnabled = profile.feedbackSuppression,
            lowLatencyMode = profile.lowLatency,
            bassGainDb = profile.bassGainDb,
            trebleGainDb = profile.trebleGainDb
        )
        audioEngine.updateSettings(_settings.value)
        persistDspSettings()
        notifyServiceSettingsChanged()
    }

    fun setHardwareMicType(type: HardwareMicType) {
        _settings.value = _settings.value.copy(hardwareMicType = type)
        audioRouter.setHardwareMicType(type)
        audioEngine.updateSettings(_settings.value)
        persistDspSettings()
    }

    fun setAudioInputSource(source: AudioInputSource) {
        _settings.value = _settings.value.copy(audioInputSource = source)
        audioEngine.updateSettings(_settings.value)
        persistDspSettings()
    }

    fun setAudioFocusPolicy(policy: AudioFocusPolicy) {
        _settings.value = _settings.value.copy(audioFocusPolicy = policy)
        audioEngine.updateSettings(_settings.value)
        persistDspSettings()
    }

    fun setAudioRoute(route: AudioRoute) {
        audioRouter.setRoute(route)
    }

    fun openMicSelectorDialog() {
        audioRouter.detectAudioDevices()
        _showMicSelectorDialog.value = true
    }

    fun dismissMicSelectorDialog() {
        _showMicSelectorDialog.value = false
    }

    fun openVoiceChatHub() {
        audioRouter.detectAudioDevices()
        _showVoiceChatHub.value = true
    }

    fun dismissVoiceChatHub() {
        _showVoiceChatHub.value = false
    }

    fun openDisclaimerDialog() {
        _showDisclaimerDialog.value = true
    }

    fun dismissDisclaimerDialog() {
        _showDisclaimerDialog.value = false
    }

    fun toggleFloatingOverlay(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
            _showOverlayPermissionDialog.value = true
            return
        }

        if (isOverlayActive.value) {
            FloatingMicOverlayService.stopOverlay(context)
            _settings.value = _settings.value.copy(floatingOverlayEnabled = false)
        } else {
            FloatingMicOverlayService.startOverlay(context)
            _settings.value = _settings.value.copy(floatingOverlayEnabled = true)
        }
        persistDspSettings()
    }

    fun dismissOverlayPermissionDialog() {
        _showOverlayPermissionDialog.value = false
    }

    fun launchVoiceApp(context: Context, packageName: String) {
        if (packageName.isEmpty()) return
        val pm = context.packageManager
        val launchIntent = pm.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            context.startActivity(launchIntent)
        } else {
            // Open Play Store
            try {
                val marketIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(marketIntent)
            } catch (_: Exception) {
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(webIntent)
            }
        }
    }

    private fun persistDspSettings() {
        viewModelScope.launch {
            try {
                dspPreferencesRepository.saveDspSettings(_settings.value)
            } catch (_: Exception) {}
        }
    }

    private fun notifyServiceSettingsChanged() {
        if (isLiveRunning.value) {
            val context = getApplication<Application>()
            val intent = Intent(context, MicAmplifierService::class.java).apply {
                action = MicAmplifierService.ACTION_UPDATE_SETTINGS
                putExtra(MicAmplifierService.EXTRA_BOOST_PERCENTAGE, _settings.value.boostPercentage)
                putExtra(MicAmplifierService.EXTRA_IS_MUTED, _settings.value.isMuted)
            }
            try {
                context.startService(intent)
            } catch (_: Exception) {}
        }
    }

    fun openMicTestModal() {
        audioRouter.detectAudioDevices()
        _showMicTestModal.value = true
    }

    fun dismissMicTestModal() {
        micTestEngine.stopAll()
        _showMicTestModal.value = false
    }

    fun startVoiceRecordTest(durationSeconds: Int = 5) {
        if (!_hasPermission.value) return
        // If main live amplifier is running, temporarily pause it to avoid resource contention
        if (isLiveRunning.value) {
            stopMic()
        }
        micTestEngine.startVoiceRecordTest(_settings.value, durationSeconds)
    }

    fun playVoiceTest(useBoosted: Boolean = true) {
        micTestEngine.playRecordedVoiceTest(useBoosted)
    }

    fun stopVoiceTestPlayback() {
        micTestEngine.stopPlayback()
    }

    fun toggleLiveLoopbackMonitor() {
        if (!_hasPermission.value) return
        if (testState.value == MicTestState.LIVE_MONITOR) {
            micTestEngine.stopLiveLoopback()
        } else {
            if (isLiveRunning.value) {
                stopMic()
            }
            micTestEngine.startLiveLoopback(_settings.value)
        }
    }

    fun stopAllTests() {
        micTestEngine.stopAll()
    }

    override fun onCleared() {
        super.onCleared()
        micTestEngine.release()
        audioRouter.release()
    }
}
