package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.viewmodel.MicViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Puti Mic", appName)
  }

  @Test
  fun `test permission state and rationale lifecycle`() {
    val app = ApplicationProvider.getApplicationContext<Application>()
    val viewModel = MicViewModel(app)

    assertFalse(viewModel.hasPermission.value)
    assertFalse(viewModel.showPermissionRationale.value)

    viewModel.showRationale(permanentlyDenied = false)
    assertTrue(viewModel.showPermissionRationale.value)
    assertFalse(viewModel.isPermanentlyDenied.value)

    viewModel.dismissRationale()
    assertFalse(viewModel.showPermissionRationale.value)

    viewModel.showRationale(permanentlyDenied = true)
    assertTrue(viewModel.showPermissionRationale.value)
    assertTrue(viewModel.isPermanentlyDenied.value)

    viewModel.setPermissionGranted(true)
    assertTrue(viewModel.hasPermission.value)
    assertFalse(viewModel.showPermissionRationale.value)
  }

  @Test
  fun `test audio engine settings update from ViewModel`() {
    val app = ApplicationProvider.getApplicationContext<Application>()
    val viewModel = MicViewModel(app)

    viewModel.setBoostPercentage(450)
    assertEquals(450, viewModel.settings.value.boostPercentage)

    viewModel.toggleMute()
    assertTrue(viewModel.settings.value.isMuted)

    viewModel.toggleSpeakerBoost()
    assertTrue(viewModel.settings.value.isSpeakerBoostEnabled)

    viewModel.emergencyReset()
    assertEquals(100, viewModel.settings.value.boostPercentage)
    assertFalse(viewModel.settings.value.isMuted)
    assertFalse(viewModel.settings.value.isSpeakerBoostEnabled)
  }

  @Test
  fun `test DSP toggles for limiter, noise reduction, and echo cancellation`() {
    val app = ApplicationProvider.getApplicationContext<Application>()
    val viewModel = MicViewModel(app)

    // Verify initial default states
    assertTrue(viewModel.settings.value.limiterEnabled)
    assertTrue(viewModel.settings.value.noiseReductionEnabled)
    assertTrue(viewModel.settings.value.echoCancellationEnabled)

    // Toggle limiter off
    viewModel.updateDsp { it.copy(limiterEnabled = false) }
    assertFalse(viewModel.settings.value.limiterEnabled)

    // Toggle noise reduction off
    viewModel.updateDsp { it.copy(noiseReductionEnabled = false) }
    assertFalse(viewModel.settings.value.noiseReductionEnabled)

    // Toggle echo cancellation off
    viewModel.updateDsp { it.copy(echoCancellationEnabled = false) }
    assertFalse(viewModel.settings.value.echoCancellationEnabled)

    // Reset to defaults
    viewModel.resetDspToDefaults()
    assertTrue(viewModel.settings.value.limiterEnabled)
    assertTrue(viewModel.settings.value.noiseReductionEnabled)
    assertTrue(viewModel.settings.value.echoCancellationEnabled)
  }

  @Test
  fun `test voice chat app profiles and presets for Hapi, Masti, and IMO`() {
    val app = ApplicationProvider.getApplicationContext<Application>()
    val viewModel = MicViewModel(app)

    // Test Hapi profile
    viewModel.applyVoiceChatProfile(com.example.data.VoiceChatProfile.HAPI)
    assertEquals("hapi", viewModel.settings.value.activeProfileId)
    assertEquals(350, viewModel.settings.value.boostPercentage)
    assertEquals(com.example.data.AudioInputSource.VOICE_COMMUNICATION, viewModel.settings.value.audioInputSource)
    assertTrue(viewModel.settings.value.echoCancellationEnabled)
    assertTrue(viewModel.settings.value.voiceClarityEnabled)

    // Test Masti profile
    viewModel.applyVoiceChatProfile(com.example.data.VoiceChatProfile.MASTI)
    assertEquals("masti", viewModel.settings.value.activeProfileId)
    assertEquals(400, viewModel.settings.value.boostPercentage)

    // Test IMO profile
    viewModel.applyVoiceChatProfile(com.example.data.VoiceChatProfile.IMO)
    assertEquals("imo", viewModel.settings.value.activeProfileId)
    assertEquals(250, viewModel.settings.value.boostPercentage)
    assertTrue(viewModel.settings.value.echoCancellationEnabled)

    // Test audio input source setting
    viewModel.setAudioInputSource(com.example.data.AudioInputSource.VOICE_RECOGNITION)
    assertEquals(com.example.data.AudioInputSource.VOICE_RECOGNITION, viewModel.settings.value.audioInputSource)

    // Test audio focus policy setting
    viewModel.setAudioFocusPolicy(com.example.data.AudioFocusPolicy.IGNORE_FOCUS_LOSS)
    assertEquals(com.example.data.AudioFocusPolicy.IGNORE_FOCUS_LOSS, viewModel.settings.value.audioFocusPolicy)
  }
}
