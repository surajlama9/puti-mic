package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.ui.PutiMicScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.MicViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: MicViewModel by viewModels()
    private var hasPromptedPermission = false

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val recordGranted = permissions[Manifest.permission.RECORD_AUDIO] == true ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

        viewModel.setPermissionGranted(recordGranted)

        if (!recordGranted) {
            val shouldShowRationale = ActivityCompat.shouldShowRequestPermissionRationale(
                this, Manifest.permission.RECORD_AUDIO
            )
            // If denied and shouldShowRationale is false, it's permanently denied
            if (!shouldShowRationale && hasPromptedPermission) {
                viewModel.showRationale(permanentlyDenied = true)
            } else {
                viewModel.showRationale(permanentlyDenied = false)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        checkInitialPermissions()

        setContent {
            MyApplicationTheme {
                PutiMicScreen(
                    viewModel = viewModel,
                    onRequestPermission = { handlePermissionRequest() },
                    onDirectGrantPermission = { launchDirectPermissionRequest() },
                    onOpenAppSettings = { openAppSettings() }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        checkInitialPermissions()
    }

    private fun checkInitialPermissions() {
        val recordAudioGranted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        viewModel.setPermissionGranted(recordAudioGranted)
    }

    private fun handlePermissionRequest() {
        val recordAudioGranted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (recordAudioGranted) {
            viewModel.setPermissionGranted(true)
            return
        }

        val shouldShowRationale = ActivityCompat.shouldShowRequestPermissionRationale(
            this, Manifest.permission.RECORD_AUDIO
        )

        if (shouldShowRationale) {
            // Show custom rationale dialog explaining voice amplification requirements
            viewModel.showRationale(permanentlyDenied = false)
        } else if (hasPromptedPermission) {
            // User may have checked "Don't ask again"
            viewModel.showRationale(permanentlyDenied = true)
        } else {
            // Show rationale first or launch permission request directly
            viewModel.showRationale(permanentlyDenied = false)
        }
    }

    private fun launchDirectPermissionRequest() {
        hasPromptedPermission = true
        val permissionsToRequest = mutableListOf(Manifest.permission.RECORD_AUDIO)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissionsToRequest.add(Manifest.permission.BLUETOOTH_CONNECT)
        }

        permissionLauncher.launch(permissionsToRequest.toTypedArray())
    }

    private fun openAppSettings() {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", packageName, null)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (e: Exception) {
            val intent = Intent(Settings.ACTION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        }
    }
}
