package com.example.ui.components

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Headset
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SettingsInputComponent
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AudioFocusPolicy
import com.example.data.AudioInputSource
import com.example.data.DspSettings
import com.example.data.HardwareMicType
import com.example.data.MicDeviceStatus
import com.example.data.VoiceChatProfile
import com.example.ui.theme.ConsoleBackground
import com.example.ui.theme.ConsoleBorder
import com.example.ui.theme.ConsoleBorderBright
import com.example.ui.theme.ConsoleSurface
import com.example.ui.theme.ConsoleSurfaceElevated
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.SafeGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningYellow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceChatHubBottomSheet(
    settings: DspSettings,
    currentProfile: VoiceChatProfile,
    isOverlayActive: Boolean,
    availableMicInputs: List<MicDeviceStatus> = emptyList(),
    selectedMicType: HardwareMicType = settings.hardwareMicType,
    onSelectMicType: (HardwareMicType) -> Unit = {},
    onSelectProfile: (VoiceChatProfile) -> Unit,
    onSelectInputSource: (AudioInputSource) -> Unit,
    onSelectFocusPolicy: (AudioFocusPolicy) -> Unit,
    onToggleFloatingOverlay: () -> Unit,
    onLaunchApp: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(0) } // 0: App Presets, 1: Hardware Mic & Routing

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = ConsoleBackground,
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 10.dp)
                    .width(40.dp)
                    .height(4.dp)
                    .clip(CircleShape)
                    .background(ConsoleBorderBright)
            )
        },
        modifier = Modifier.testTag("voice_chat_hub_bottom_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(NeonCyan, ElectricViolet))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Headset,
                            contentDescription = null,
                            tint = Color(0xFF030712),
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Column {
                        Text(
                            text = "VOICE CHAT APP COMPANION",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "Hapi • Masti • IMO • Discord • WhatsApp",
                            fontSize = 11.sp,
                            color = NeonCyan,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("close_voice_chat_hub_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Floating Overlay Quick Switch Banner
            FloatingOverlayBanner(
                isOverlayActive = isOverlayActive,
                onToggleOverlay = onToggleFloatingOverlay
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Tabs (App Presets vs Hardware Mic & Routing)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(ConsoleSurfaceElevated)
                    .border(1.dp, ConsoleBorder, RoundedCornerShape(10.dp))
                    .padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                TabButton(
                    title = "App Presets (Hapi/Masti/IMO)",
                    isSelected = selectedTab == 0,
                    modifier = Modifier.weight(1f),
                    onClick = { selectedTab = 0 }
                )
                TabButton(
                    title = "Hardware Mic & Routing",
                    isSelected = selectedTab == 1,
                    modifier = Modifier.weight(1f),
                    onClick = { selectedTab = 1 }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (selectedTab == 0) {
                // List of Presets
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(390.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    items(VoiceChatProfile.values()) { profile ->
                        val isSelected = currentProfile == profile
                        VoiceAppProfileCard(
                            profile = profile,
                            isSelected = isSelected,
                            onSelect = { onSelectProfile(profile) },
                            onLaunch = { onLaunchApp(profile.packageName) }
                        )
                    }
                }
            } else {
                // Hardware Mic Selection, Audio Source & Focus Policy Configuration
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(390.dp)
                        .verticalScroll(rememberScrollState())
                        .padding(bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "MICROPHONE HARDWARE INPUT (ALL-IN-ONE)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeonCyan
                    )

                    // Hardware Mic Options List
                    val micTypes = listOf(
                        HardwareMicType.AUTO to ("All-In-One (Auto Smart)" to Icons.Default.AutoAwesome),
                        HardwareMicType.PHONE_MIC to ("Device Built-in Mic" to Icons.Default.PhoneAndroid),
                        HardwareMicType.BLUETOOTH_MIC to ("Bluetooth Mic (Wireless)" to Icons.Default.Bluetooth),
                        HardwareMicType.WIRED_MIC to ("Wired / USB Mic" to Icons.Default.Headphones)
                    )

                    micTypes.forEach { (type, meta) ->
                        val (title, icon) = meta
                        val isSelected = selectedMicType == type
                        val status = availableMicInputs.find { it.type == type }
                        val isConnected = status?.isConnected ?: (type == HardwareMicType.AUTO || type == HardwareMicType.PHONE_MIC)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) ConsoleSurfaceElevated else ConsoleSurface)
                                .border(
                                    1.dp,
                                    if (isSelected) NeonCyan else ConsoleBorder,
                                    RoundedCornerShape(10.dp)
                                )
                                .clickable { onSelectMicType(type) }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = null,
                                    tint = if (isSelected) NeonCyan else TextSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Column {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = title,
                                            color = if (isSelected) NeonCyan else TextPrimary,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        if (isConnected) {
                                            SpecBadge(
                                                label = if (type == HardwareMicType.AUTO) "SMART" else "CONNECTED",
                                                color = SafeGreen
                                            )
                                        }
                                    }
                                    Text(
                                        text = status?.details?.ifEmpty { type.subtitle } ?: type.subtitle,
                                        color = TextMuted,
                                        fontSize = 9.5.sp,
                                        lineHeight = 12.sp
                                    )
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .padding(start = 8.dp)
                                    .size(16.dp)
                                    .clip(CircleShape)
                                    .background(if (isSelected) NeonCyan else ConsoleBorder)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "ANDROID HAL AUDIO CAPTURE SOURCE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = ElectricViolet
                    )

                    AudioInputSource.values().forEach { source ->
                        val isCurrentSource = settings.audioInputSource == source
                        AudioSourceItem(
                            source = source,
                            isSelected = isCurrentSource,
                            onClick = { onSelectInputSource(source) }
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "AUDIO FOCUS (BACKGROUND BEHAVIOR)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = WarningYellow
                    )

                    AudioFocusPolicy.values().forEach { policy ->
                        val isCurrentPolicy = settings.audioFocusPolicy == policy
                        AudioFocusItem(
                            policy = policy,
                            isSelected = isCurrentPolicy,
                            onClick = { onSelectFocusPolicy(policy) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FloatingOverlayBanner(
    isOverlayActive: Boolean,
    onToggleOverlay: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(
                Brush.horizontalGradient(
                    listOf(
                        ElectricViolet.copy(alpha = 0.18f),
                        NeonCyan.copy(alpha = 0.12f)
                    )
                )
            )
            .border(
                1.dp,
                if (isOverlayActive) NeonCyan else ConsoleBorderBright,
                RoundedCornerShape(12.dp)
            )
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(if (isOverlayActive) NeonCyan else ConsoleSurfaceElevated),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Layers,
                        contentDescription = null,
                        tint = if (isOverlayActive) Color(0xFF030712) else TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Column {
                    Text(
                        text = "Floating Quick Bubble",
                        color = TextPrimary,
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (isOverlayActive) "Active on top of Hapi / Masti / IMO" else "Control mic gain inside voice chat rooms",
                        color = if (isOverlayActive) SafeGreen else TextMuted,
                        fontSize = 10.sp
                    )
                }
            }

            Switch(
                checked = isOverlayActive,
                onCheckedChange = { onToggleOverlay() },
                modifier = Modifier.testTag("floating_overlay_toggle_switch"),
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color(0xFF030712),
                    checkedTrackColor = NeonCyan,
                    uncheckedThumbColor = TextMuted,
                    uncheckedTrackColor = ConsoleSurfaceElevated
                )
            )
        }
    }
}

@Composable
private fun VoiceAppProfileCard(
    profile: VoiceChatProfile,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onLaunch: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) ConsoleSurfaceElevated else ConsoleSurface
        ),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = if (isSelected) Brush.horizontalGradient(listOf(profile.accentColor, ElectricViolet)) else Brush.linearGradient(listOf(ConsoleBorder, ConsoleBorder))
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect() }
            .testTag("voice_profile_card_${profile.id}")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(profile.accentColor)
                    )
                    Text(
                        text = profile.title,
                        color = TextPrimary,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (isSelected) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = SafeGreen,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "ACTIVE",
                            color = SafeGreen,
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Text(
                text = profile.subtitle,
                color = TextSecondary,
                fontSize = 11.sp,
                modifier = Modifier.padding(vertical = 4.dp)
            )

            // Specs badges
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                SpecBadge(label = "Gain: +${profile.recommendedBoost}%", color = profile.accentColor)
                SpecBadge(label = "AEC: Echo Filter", color = NeonCyan)
                SpecBadge(label = "Voice Gate", color = ElectricViolet)
            }

            Text(
                text = profile.tips,
                color = TextMuted,
                fontSize = 9.5.sp,
                lineHeight = 13.sp,
                modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onSelect,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSelected) profile.accentColor else ConsoleSurfaceElevated,
                        contentColor = if (isSelected) Color(0xFF030712) else TextPrimary
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(34.dp)
                        .testTag("apply_profile_${profile.id}")
                ) {
                    Text(
                        text = if (isSelected) "PRESET APPLIED" else "APPLY PRESET",
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (profile.packageName.isNotEmpty()) {
                    OutlinedButton(
                        onClick = onLaunch,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("launch_app_${profile.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.OpenInNew,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "OPEN APP",
                            color = NeonCyan,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SpecBadge(label: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(color.copy(alpha = 0.12f))
            .border(1.dp, color.copy(alpha = 0.35f), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(text = label, color = color, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun TabButton(
    title: String,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) NeonCyan else Color.Transparent)
            .clickable { onClick() }
            .padding(vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            color = if (isSelected) Color(0xFF030712) else TextSecondary,
            fontSize = 10.5.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
        )
    }
}

@Composable
private fun AudioSourceItem(
    source: AudioInputSource,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) ConsoleSurfaceElevated else ConsoleSurface)
            .border(
                1.dp,
                if (isSelected) NeonCyan else ConsoleBorder,
                RoundedCornerShape(8.dp)
            )
            .clickable { onClick() }
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = source.displayName,
                    color = if (isSelected) NeonCyan else TextPrimary,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Bold
                )
                if (source.isVoipRecommended) {
                    SpecBadge(label = "VOIP READY", color = SafeGreen)
                }
            }
            Text(
                text = source.description,
                color = TextMuted,
                fontSize = 9.5.sp,
                lineHeight = 13.sp
            )
        }

        Box(
            modifier = Modifier
                .padding(start = 8.dp)
                .size(16.dp)
                .clip(CircleShape)
                .background(if (isSelected) NeonCyan else ConsoleBorder)
        )
    }
}

@Composable
private fun AudioFocusItem(
    policy: AudioFocusPolicy,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) ConsoleSurfaceElevated else ConsoleSurface)
            .border(
                1.dp,
                if (isSelected) ElectricViolet else ConsoleBorder,
                RoundedCornerShape(8.dp)
            )
            .clickable { onClick() }
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = policy.displayName,
                color = if (isSelected) ElectricViolet else TextPrimary,
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = policy.description,
                color = TextMuted,
                fontSize = 9.5.sp,
                lineHeight = 13.sp
            )
        }

        Box(
            modifier = Modifier
                .padding(start = 8.dp)
                .size(16.dp)
                .clip(CircleShape)
                .background(if (isSelected) ElectricViolet else ConsoleBorder)
        )
    }
}
