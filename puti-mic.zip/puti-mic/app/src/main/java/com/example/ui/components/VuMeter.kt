package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ConsoleBorder
import com.example.ui.theme.ConsoleSurface
import com.example.ui.theme.ConsoleSurfaceElevated
import com.example.ui.theme.DangerRed
import com.example.ui.theme.MeterGreen
import com.example.ui.theme.MeterOrange
import com.example.ui.theme.MeterRed
import com.example.ui.theme.MeterYellow
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun VuMeter(
    inputDb: Float,
    outputDb: Float,
    isClipping: Boolean,
    isLive: Boolean,
    isMuted: Boolean,
    modifier: Modifier = Modifier
) {
    // Normalize dB (-60 dB to 0 dB, output up to +6dB) into 0.0 -> 1.0 fraction
    val rawInFraction = if (isLive) ((inputDb + 60f) / 60f).coerceIn(0f, 1f) else 0f
    val rawOutFraction = if (isLive && !isMuted) ((outputDb + 60f) / 66f).coerceIn(0f, 1f) else 0f

    val inFraction by animateFloatAsState(
        targetValue = rawInFraction,
        animationSpec = tween(50),
        label = "in_fraction"
    )

    val outFraction by animateFloatAsState(
        targetValue = rawOutFraction,
        animationSpec = tween(50),
        label = "out_fraction"
    )

    val clipColor by animateColorAsState(
        targetValue = if (isClipping && isLive && !isMuted) DangerRed else ConsoleSurfaceElevated,
        animationSpec = tween(100),
        label = "clip_led_color"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(ConsoleSurface)
            .border(1.dp, ConsoleBorder, RoundedCornerShape(14.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .testTag("vu_meter_section")
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Header with Overload Warning LED
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "DUAL VU METERS",
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(clipColor)
                    )
                    Text(
                        text = if (isClipping && isLive && !isMuted) "LIMITER ENGAGED" else "OPTIMAL HEADROOM",
                        color = if (isClipping && isLive && !isMuted) DangerRed else TextMuted,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Input Meter Bar
            MeterRow(
                label = "MIC IN",
                dbValue = if (isLive) inputDb else -60f,
                fraction = inFraction,
                testTag = "input_vu_bar"
            )

            // Output Meter Bar
            MeterRow(
                label = "AMP OUT",
                dbValue = if (isLive && !isMuted) outputDb else -60f,
                fraction = outFraction,
                testTag = "output_vu_bar"
            )
        }
    }
}

@Composable
private fun MeterRow(
    label: String,
    dbValue: Float,
    fraction: Float,
    testTag: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = TextMuted,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.width(58.dp)
        )

        Box(
            modifier = Modifier
                .weight(1f)
                .height(14.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(ConsoleSurfaceElevated)
                .border(0.5.dp, ConsoleBorder, RoundedCornerShape(4.dp))
                .testTag(testTag)
        ) {
            // Filled dynamic meter with standard studio color stops
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(fraction)
                    .clip(RoundedCornerShape(4.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                MeterGreen,
                                MeterYellow,
                                MeterOrange,
                                MeterRed
                            )
                        )
                    )
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        Text(
            text = String.format(Locale.US, "%+4.1f dB", dbValue),
            color = if (dbValue > -3f) MeterRed else if (dbValue > -12f) MeterYellow else TextPrimary,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.width(52.dp)
        )
    }
}
