package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val PutiMicColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = Color(0xFF030712),
    primaryContainer = Color(0xFF003640),
    onPrimaryContainer = NeonCyan,
    secondary = ElectricViolet,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF38006B),
    onSecondaryContainer = Color(0xFFE0AAFF),
    tertiary = NeonPink,
    onTertiary = Color.White,
    background = ConsoleBackground,
    onBackground = TextPrimary,
    surface = ConsoleSurface,
    onSurface = TextPrimary,
    surfaceVariant = ConsoleSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = ConsoleBorder,
    outlineVariant = ConsoleBorderBright,
    error = DangerRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    // Puti Mic is an audio amplifier console and strictly uses the high-contrast dark neon console theme
    MaterialTheme(
        colorScheme = PutiMicColorScheme,
        typography = Typography,
        content = content
    )
}
