package com.example.audio

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.DspSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Foreground Service that manages the AudioRecord and AudioTrack lifecycle
 * to ensure continuous, low-latency microphone amplification while the app is in the foreground or background.
 */
class MicAmplifierService : Service() {

    private val TAG = "MicAmplifierService"
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val binder = LocalBinder()

    inner class LocalBinder : Binder() {
        fun getService(): MicAmplifierService = this@MicAmplifierService
    }

    companion object {
        const val CHANNEL_ID = "puti_mic_foreground_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.example.putimic.ACTION_START"
        const val ACTION_STOP = "com.example.putimic.ACTION_STOP"
        const val ACTION_TOGGLE_MUTE = "com.example.putimic.ACTION_TOGGLE_MUTE"
        const val ACTION_UPDATE_SETTINGS = "com.example.putimic.ACTION_UPDATE_SETTINGS"

        const val EXTRA_BOOST_PERCENTAGE = "extra_boost_percentage"
        const val EXTRA_IS_MUTED = "extra_is_muted"

        @Volatile
        private var sharedEngine: MicAudioEngine? = null

        fun getAudioEngine(context: Context): MicAudioEngine {
            return sharedEngine ?: synchronized(this) {
                sharedEngine ?: MicAudioEngine(context.applicationContext).also { sharedEngine = it }
            }
        }

        private val _isServiceRunning = MutableStateFlow(false)
        val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

        fun startService(context: Context, boostPercentage: Int = 150) {
            val intent = Intent(context, MicAmplifierService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_BOOST_PERCENTAGE, boostPercentage)
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (e: Exception) {
                Log.e("MicAmplifierService", "Failed to start foreground service: ${e.message}")
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, MicAmplifierService::class.java).apply {
                action = ACTION_STOP
            }
            try {
                context.startService(intent)
            } catch (e: Exception) {
                Log.e("MicAmplifierService", "Failed to stop foreground service: ${e.message}")
            }
        }

        fun toggleMute(context: Context) {
            val intent = Intent(context, MicAmplifierService::class.java).apply {
                action = ACTION_TOGGLE_MUTE
            }
            try {
                context.startService(intent)
            } catch (e: Exception) {
                Log.e("MicAmplifierService", "Failed to send toggle mute action: ${e.message}")
            }
        }
    }

    private lateinit var audioEngine: MicAudioEngine
    private var currentBoostPercentage: Int = 150
    private var isMuted: Boolean = false

    override fun onCreate() {
        super.onCreate()
        audioEngine = getAudioEngine(this)
        createNotificationChannel()

        // Observe live running state from audio engine
        serviceScope.launch {
            audioEngine.isLiveRunning.collect { isRunning ->
                _isServiceRunning.value = isRunning
                if (!isRunning && _isServiceRunning.value) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder = binder

    @SuppressLint("MissingPermission")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                handleStop()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE_MUTE -> {
                isMuted = !isMuted
                val newSettings = audioEngine.getCurrentSettings().copy(isMuted = isMuted)
                audioEngine.updateSettings(newSettings)
                updateNotification()
                return START_STICKY
            }
            ACTION_UPDATE_SETTINGS -> {
                currentBoostPercentage = intent.getIntExtra(EXTRA_BOOST_PERCENTAGE, currentBoostPercentage)
                isMuted = intent.getBooleanExtra(EXTRA_IS_MUTED, isMuted)
                updateNotification()
                return START_STICKY
            }
            ACTION_START, null -> {
                currentBoostPercentage = intent?.getIntExtra(EXTRA_BOOST_PERCENTAGE, currentBoostPercentage) ?: currentBoostPercentage
                isMuted = audioEngine.getCurrentSettings().isMuted
                handleStart()
            }
        }
        return START_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun handleStart() {
        // Start Foreground Notification first (MANDATORY on Android 8+)
        val notification = buildNotification(currentBoostPercentage, isMuted)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    startForeground(
                        NOTIFICATION_ID,
                        notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                    )
                } else {
                    startForeground(NOTIFICATION_ID, notification)
                }
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            Log.e(TAG, "startForeground error: ${e.message}", e)
        }

        // Start AudioRecord and AudioTrack processing pipeline
        if (!audioEngine.isLiveRunning.value) {
            audioEngine.start()
        }
        _isServiceRunning.value = true
    }

    private fun handleStop() {
        _isServiceRunning.value = false
        audioEngine.stop()
        try {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } catch (e: Exception) {
            Log.w(TAG, "stopForeground error: ${e.message}")
        }
        stopSelf()
    }

    private fun updateNotification() {
        if (_isServiceRunning.value) {
            val notification = buildNotification(currentBoostPercentage, isMuted)
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.notify(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Puti Mic Live Amplifier",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Persistent background microphone processing and live amplification status"
                setShowBadge(false)
                setSound(null, null)
                enableVibration(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(boostPercentage: Int, isMuted: Boolean): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingOpenApp = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Stop Mic Action
        val stopIntent = Intent(this, MicAmplifierService::class.java).apply {
            action = ACTION_STOP
        }
        val pendingStop = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Toggle Mute Action
        val muteIntent = Intent(this, MicAmplifierService::class.java).apply {
            action = ACTION_TOGGLE_MUTE
        }
        val pendingMute = PendingIntent.getService(
            this, 2, muteIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val statusText = if (isMuted) {
            "MUTED • Tap Unmute to resume live audio"
        } else {
            "Active in background • Boost: $boostPercentage%"
        }

        val muteActionLabel = if (isMuted) "Unmute" else "Mute"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("PUTI MIC - ACTIVE AMPLIFIER")
            .setContentText(statusText)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pendingOpenApp)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(android.R.drawable.ic_media_pause, muteActionLabel, pendingMute)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop Mic", pendingStop)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        _isServiceRunning.value = false
        audioEngine.stop()
        serviceScope.cancel()
        super.onDestroy()
    }
}
