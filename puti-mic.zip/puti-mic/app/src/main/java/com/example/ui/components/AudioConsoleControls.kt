package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headset
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DspSettings
import com.example.data.VoiceChatProfile
import com.example.ui.theme.ConsoleBackground
import com.example.ui.theme.ConsoleBorder
import com.example.ui.theme.ConsoleBorderBright
import com.example.ui.theme.ConsoleSurface
import com.example.ui.theme.ConsoleSurfaceElevated
import com.example.ui.theme.DangerRed
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.FieryOrange
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.SafeGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningYellow
import java.util.Locale
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AudioConsoleControls(
    isLive: Boolean,
    settings: DspSettings,
    currentProfile: VoiceChatProfile,
    isOverlayActive: Boolean,
    onToggleLive: () -> Unit,
    onToggleMute: () -> Unit,
    onToggleSpeakerBoost: () -> Unit,
    onEmergencyReset: () -> Unit,
    onUpdateDsp: ((DspSettings) -> DspSettings) -> Unit,
    onOpenVoiceChatHub: () -> Unit,
    onOpenMicTest: () -> Unit = {},
    onToggleOverlay: () -> Unit,
    modifier: Modifier = Modifier
) {
    var expandedAdvanced by remember { mutableStateOf(false) }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Voice Chat Companion & Mic Test Hub Actions
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(
                    Brush.horizontalGradient(
                        listOf(
                            ConsoleSurface,
                            ConsoleSurfaceElevated
                        )
                    )
                )
                .border(1.dp, NeonCyan.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                .padding(14.dp)
                .testTag("voice_chat_companion_card")
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(currentProfile.accentColor),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Headset,
                                contentDescription = null,
                                tint = Color(0xFF030712),
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "VOICE CHAT COMPANION",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(currentProfile.accentColor.copy(alpha = 0.15f))
                                        .padding(horizontal = 5.dp, vertical = 1.dp)
                                ) {
                                    Text(
                                        text = currentProfile.title.uppercase(Locale.ROOT),
                                        color = currentProfile.accentColor,
                                        fontSize = 8.5.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                            Text(
                                text = "Hapi • Masti • IMO • Discord • WhatsApp",
                                fontSize = 9.5.sp,
                                color = NeonCyan
                            )
                        }
                    }

                    // Floating Overlay quick toggle button
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isOverlayActive) NeonCyan.copy(alpha = 0.15f) else ConsoleSurface)
                            .border(
                                1.dp,
                                if (isOverlayActive) NeonCyan else ConsoleBorder,
                                RoundedCornerShape(8.dp)
                            )
                            .clickable { onToggleOverlay() }
                            .padding(horizontal = 8.dp, vertical = 5.dp)
                            .testTag("quick_toggle_floating_bubble")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Layers,
                            contentDescription = null,
                            tint = if (isOverlayActive) NeonCyan else TextSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = if (isOverlayActive) "BUBBLE ON" else "BUBBLE",
                            color = if (isOverlayActive) NeonCyan else TextSecondary,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onOpenVoiceChatHub,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Brush.horizontalGradient(listOf(NeonCyan, ElectricViolet)).let { Color(0xFF00E5FF) },
                            contentColor = Color(0xFF030712)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp)
                            .testTag("open_voice_chat_hub_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Equalizer,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "APP PRESETS",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = onOpenMicTest,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ElectricViolet,
                            contentColor = Color(0xFF030712)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp)
                            .testTag("open_mic_test_hub_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Hearing,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "🎙️ TEST & LISTEN",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Primary Action Controls (START/STOP, MUTE, SPEAKER BOOST, EMERGENCY RESET)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Big START / STOP Button
            Button(
                onClick = onToggleLive,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isLive) DangerRed else NeonCyan,
                    contentColor = if (isLive) Color.White else Color(0xFF030712)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1.3f)
                    .height(56.dp)
                    .testTag("main_toggle_live_button")
            ) {
                Icon(
                    imageVector = if (isLive) Icons.Default.PowerSettingsNew else Icons.Default.Mic,
                    contentDescription = if (isLive) "Stop Mic" else "Start Mic",
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column(horizontalAlignment = Alignment.Start) {
                    Text(
                        text = if (isLive) "STOP MIC" else "START MIC",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = if (isLive) "LIVE AMPLIFIER" else "READY TO BOOST",
                        fontSize = 9.sp,
                        color = if (isLive) Color.White.copy(alpha = 0.8f) else Color(0xFF030712).copy(alpha = 0.8f)
                    )
                }
            }

            // Quick Mute Button
            Button(
                onClick = onToggleMute,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (settings.isMuted) DangerRed.copy(alpha = 0.2f) else ConsoleSurfaceElevated,
                    contentColor = if (settings.isMuted) DangerRed else TextPrimary
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(56.dp)
                    .border(
                        1.dp,
                        if (settings.isMuted) DangerRed else ConsoleBorder,
                        RoundedCornerShape(12.dp)
                    )
                    .testTag("mute_toggle_button")
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = if (settings.isMuted) Icons.Default.MicOff else Icons.Default.VolumeMute,
                        contentDescription = "Mute",
                        tint = if (settings.isMuted) DangerRed else NeonCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = if (settings.isMuted) "MUTED" else "MUTE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Loudspeaker Boost Expansion Button
            Button(
                onClick = onToggleSpeakerBoost,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (settings.isSpeakerBoostEnabled) NeonPink.copy(alpha = 0.2f) else ConsoleSurfaceElevated,
                    contentColor = if (settings.isSpeakerBoostEnabled) NeonPink else TextPrimary
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(56.dp)
                    .border(
                        1.dp,
                        if (settings.isSpeakerBoostEnabled) NeonPink else ConsoleBorder,
                        RoundedCornerShape(12.dp)
                    )
                    .testTag("speaker_boost_toggle_button")
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = "Speaker Boost",
                        tint = if (settings.isSpeakerBoostEnabled) NeonPink else FieryOrange,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = if (settings.isSpeakerBoostEnabled) "+3dB SPK" else "SPK BOOST",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Emergency Reset Safe Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(ConsoleSurface)
                .border(1.dp, ConsoleBorder, RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = "Safe State",
                    tint = SafeGreen,
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = "Safety Limiter Active (Prevents Clipping)",
                    color = TextSecondary,
                    fontSize = 10.sp
                )
            }

            Button(
                onClick = onEmergencyReset,
                colors = ButtonDefaults.buttonColors(
                    containerColor = DangerRed.copy(alpha = 0.15f),
                    contentColor = DangerRed
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .height(30.dp)
                    .border(1.dp, DangerRed.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                    .testTag("emergency_reset_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Reset",
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("RESET (100%)", fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Advanced DSP Audio Tools Expandable Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(ConsoleSurface)
                .border(1.dp, ConsoleBorder, RoundedCornerShape(16.dp))
                .padding(14.dp)
                .testTag("dsp_audio_tools_card")
        ) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { expandedAdvanced = !expandedAdvanced },
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Column {
                            Text(
                                text = "DSP AUDIO PROCESSOR",
                                color = TextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "Clarity • Noise Gate • AEC • Anti-Feedback • Equalizer",
                                color = TextMuted,
                                fontSize = 9.5.sp
                            )
                        }
                    }

                    Text(
                        text = if (expandedAdvanced) "HIDE ▲" else "EXPAND ▼",
                        color = NeonCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                AnimatedVisibility(
                    visible = expandedAdvanced,
                    enter = expandVertically() + fadeIn(),
                    exit = shrinkVertically() + fadeOut()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 14.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Toggles Grid
                        DspToggleRow(
                            title = "Audio Limiter & Peak Protection",
                            subtitle = "Prevents harsh digital clipping & protects hearing",
                            icon = Icons.Default.Security,
                            checked = settings.limiterEnabled,
                            testTag = "dsp_toggle_audio_limiter",
                            onCheckedChange = { onUpdateDsp { s -> s.copy(limiterEnabled = it) } }
                        )

                        DspToggleRow(
                            title = "Noise Reduction & Noise Gate",
                            subtitle = "Eliminates room hiss and ambient background noise",
                            icon = Icons.Default.Hearing,
                            checked = settings.noiseReductionEnabled,
                            testTag = "dsp_toggle_noise_reduction",
                            onCheckedChange = { onUpdateDsp { s -> s.copy(noiseReductionEnabled = it) } }
                        )

                        DspToggleRow(
                            title = "Acoustic Echo Cancellation (AEC)",
                            subtitle = "Prevents speaker audio from looping back into mic",
                            icon = Icons.Default.GraphicEq,
                            checked = settings.echoCancellationEnabled,
                            testTag = "dsp_toggle_echo_cancellation",
                            onCheckedChange = { onUpdateDsp { s -> s.copy(echoCancellationEnabled = it) } }
                        )

                        DspToggleRow(
                            title = "Voice Clarity Enhancement",
                            subtitle = "Boosts 2.8kHz vocal presence & filters low rumble",
                            icon = Icons.Default.RecordVoiceOver,
                            checked = settings.voiceClarityEnabled,
                            testTag = "dsp_toggle_voice_clarity",
                            onCheckedChange = { onUpdateDsp { s -> s.copy(voiceClarityEnabled = it) } }
                        )

                        DspToggleRow(
                            title = "Anti-Feedback Suppression",
                            subtitle = "Adaptive notch filters to dampen howling squeals",
                            icon = Icons.Default.Security,
                            checked = settings.feedbackSuppressionEnabled,
                            testTag = "dsp_toggle_feedback_suppression",
                            onCheckedChange = { onUpdateDsp { s -> s.copy(feedbackSuppressionEnabled = it) } }
                        )

                        DspToggleRow(
                            title = "Automatic Gain Control (AGC)",
                            subtitle = "Dynamic leveling for varying speaker distances",
                            icon = Icons.Default.Equalizer,
                            checked = settings.autoGainControl,
                            testTag = "dsp_toggle_agc",
                            onCheckedChange = { onUpdateDsp { s -> s.copy(autoGainControl = it) } }
                        )

                        DspToggleRow(
                            title = "Ultra Low Latency Buffer",
                            subtitle = "Optimized fast-track buffer for minimal delay",
                            icon = Icons.Default.Speed,
                            checked = settings.lowLatencyMode,
                            testTag = "dsp_toggle_low_latency",
                            onCheckedChange = { onUpdateDsp { s -> s.copy(lowLatencyMode = it) } }
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        // Tone Controls (Bass & Treble)
                        Text(
                            text = "EQUALIZER TONE SHAPING",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = NeonCyan
                        )

                        EqualizerSlider(
                            label = "Bass (180 Hz Low-Shelf)",
                            gainDb = settings.bassGainDb,
                            onGainChange = { onUpdateDsp { s -> s.copy(bassGainDb = it) } }
                        )

                        EqualizerSlider(
                            label = "Treble (5.0 kHz High-Shelf)",
                            gainDb = settings.trebleGainDb,
                            onGainChange = { onUpdateDsp { s -> s.copy(trebleGainDb = it) } }
                        )

                        Spacer(modifier = Modifier.height(2.dp))

                        // DataStore persistence indicator & reset DSP
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(SafeGreen)
                                )
                                Text(
                                    text = "DataStore auto-persisted",
                                    color = TextMuted,
                                    fontSize = 9.sp
                                )
                            }

                            Button(
                                onClick = {
                                    onUpdateDsp { s ->
                                        s.copy(
                                            noiseReductionEnabled = true,
                                            echoCancellationEnabled = true,
                                            limiterEnabled = true,
                                            feedbackSuppressionEnabled = true,
                                            voiceClarityEnabled = true,
                                            lowLatencyMode = true,
                                            autoGainControl = false,
                                            bassGainDb = 0f,
                                            trebleGainDb = 0f
                                        )
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = ConsoleSurfaceElevated,
                                    contentColor = NeonCyan
                                ),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .height(28.dp)
                                    .border(1.dp, ConsoleBorder, RoundedCornerShape(6.dp))
                                    .testTag("reset_dsp_defaults_button")
                            ) {
                                Text("RESET DSP DEFAULTS", fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DspToggleRow(
    title: String,
    subtitle: String,
    icon: ImageVector,
    checked: Boolean,
    testTag: String = "",
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(ConsoleSurfaceElevated)
            .border(1.dp, ConsoleBorder, RoundedCornerShape(10.dp))
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(if (checked) NeonCyan.copy(alpha = 0.15f) else ConsoleBorder),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (checked) NeonCyan else TextSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }

            Column {
                Text(
                    text = title,
                    color = TextPrimary,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = subtitle,
                    color = TextMuted,
                    fontSize = 9.sp,
                    lineHeight = 12.sp
                )
            }
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = if (testTag.isNotEmpty()) Modifier.testTag(testTag) else Modifier,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color(0xFF030712),
                checkedTrackColor = NeonCyan,
                uncheckedThumbColor = TextMuted,
                uncheckedTrackColor = ConsoleBackground
            )
        )
    }
}

@Composable
private fun EqualizerSlider(
    label: String,
    gainDb: Float,
    onGainChange: (Float) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(ConsoleSurfaceElevated)
            .border(1.dp, ConsoleBorder, RoundedCornerShape(10.dp))
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = label, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Medium)
            Text(
                text = "${if (gainDb > 0) "+" else ""}${String.format(Locale.ROOT, "%.1f", gainDb)} dB",
                color = if (gainDb != 0f) NeonCyan else TextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }

        Slider(
            value = gainDb,
            onValueChange = { onGainChange(it) },
            valueRange = -12f..12f,
            steps = 24,
            colors = SliderDefaults.colors(
                thumbColor = NeonCyan,
                activeTrackColor = NeonCyan,
                inactiveTrackColor = ConsoleBorder
            ),
            modifier = Modifier.fillMaxWidth()
        )
    }
}
