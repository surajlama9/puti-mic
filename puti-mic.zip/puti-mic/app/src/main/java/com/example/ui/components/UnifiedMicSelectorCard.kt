package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.SettingsInputComponent
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.HardwareMicType
import com.example.data.MicDeviceStatus
import com.example.ui.theme.ConsoleBorder
import com.example.ui.theme.ConsoleBorderBright
import com.example.ui.theme.ConsoleSurface
import com.example.ui.theme.ConsoleSurfaceElevated
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.FieryOrange
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.SafeGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningYellow

@Composable
fun UnifiedMicSelectorCard(
    selectedMicType: HardwareMicType,
    activeMicStatus: MicDeviceStatus,
    availableMicInputs: List<MicDeviceStatus>,
    onSelectMicType: (HardwareMicType) -> Unit,
    modifier: Modifier = Modifier
) {
    var showFullDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(ConsoleSurface)
            .border(1.dp, ConsoleBorder, RoundedCornerShape(16.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Header Row with Live Active Hardware Status
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.SettingsInputComponent,
                    contentDescription = "Mic Input Hardware",
                    tint = NeonCyan,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "MIC INPUT HARDWARE",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            // Current Active Hardware Pill (Clickable to open dialog)
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(ConsoleSurfaceElevated)
                    .border(1.dp, NeonCyan.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                    .clickable { showFullDialog = true }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .testTag("active_mic_info_pill"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                // Blinking / Active status dot
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(SafeGreen)
                )
                Text(
                    text = activeMicStatus.name.take(18),
                    color = NeonCyan,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = "Details",
                    tint = TextSecondary,
                    modifier = Modifier.size(12.dp)
                )
            }
        }

        // 4-Column Quick Selector Tabs (All-in-One, Phone Mic, Bluetooth, Wired)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val micOptions = listOf(
                HardwareMicType.AUTO to ("Auto All-in-One" to Icons.Default.AutoAwesome),
                HardwareMicType.PHONE_MIC to ("Device Mic" to Icons.Default.PhoneAndroid),
                HardwareMicType.BLUETOOTH_MIC to ("BT Mic" to Icons.Default.Bluetooth),
                HardwareMicType.WIRED_MIC to ("Wired / USB" to Icons.Default.Headphones)
            )

            micOptions.forEach { (type, meta) ->
                val (label, icon) = meta
                val isSelected = selectedMicType == type
                val statusInfo = availableMicInputs.find { it.type == type }
                val isConnected = statusInfo?.isConnected ?: (type == HardwareMicType.AUTO || type == HardwareMicType.PHONE_MIC)

                val backgroundColor by animateColorAsState(
                    targetValue = if (isSelected) ConsoleSurfaceElevated else Color(0xFF0C101D),
                    label = "micTabBg"
                )
                val borderColor by animateColorAsState(
                    targetValue = if (isSelected) NeonCyan else ConsoleBorder,
                    label = "micTabBorder"
                )

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(backgroundColor)
                        .border(
                            width = if (isSelected) 1.5.dp else 1.dp,
                            color = borderColor,
                            shape = RoundedCornerShape(10.dp)
                        )
                        .clickable { onSelectMicType(type) }
                        .padding(vertical = 8.dp, horizontal = 4.dp)
                        .testTag("mic_selector_${type.name.lowercase()}"),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(contentAlignment = Alignment.TopEnd) {
                            Icon(
                                imageVector = icon,
                                contentDescription = label,
                                tint = if (isSelected) NeonCyan else if (isConnected) TextPrimary else TextMuted,
                                modifier = Modifier.size(18.dp)
                            )
                            if (isConnected && type != HardwareMicType.AUTO && type != HardwareMicType.PHONE_MIC) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(SafeGreen)
                                )
                            }
                        }

                        Text(
                            text = label,
                            color = if (isSelected) NeonCyan else if (isConnected) TextPrimary else TextMuted,
                            fontSize = 9.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        // Live Description Banner
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF0A0E1A))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val typeIcon = when (selectedMicType) {
                HardwareMicType.AUTO -> Icons.Default.AutoAwesome
                HardwareMicType.PHONE_MIC -> Icons.Default.PhoneAndroid
                HardwareMicType.BLUETOOTH_MIC -> Icons.Default.Bluetooth
                HardwareMicType.WIRED_MIC -> Icons.Default.Headphones
            }

            Icon(
                imageVector = typeIcon,
                contentDescription = null,
                tint = if (selectedMicType == HardwareMicType.AUTO) ElectricViolet else NeonCyan,
                modifier = Modifier.size(14.dp)
            )

            Text(
                text = activeMicStatus.details.ifEmpty { selectedMicType.subtitle },
                color = TextSecondary,
                fontSize = 10.sp,
                lineHeight = 13.sp
            )
        }
    }

    // Hardware Details & Routing Modal Dialog
    if (showFullDialog) {
        AlertDialog(
            onDismissRequest = { showFullDialog = false },
            containerColor = ConsoleSurfaceElevated,
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.SettingsInputComponent,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = "Unified Hardware Mic Routing",
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Puti Mic supports Phone Built-in Mics, Bluetooth Headsets/Lapels, and 3.5mm/USB Lavalier Mics with low-latency DSP.",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )

                    availableMicInputs.forEach { mic ->
                        val isCurrentSelected = selectedMicType == mic.type
                        val icon = when (mic.type) {
                            HardwareMicType.AUTO -> Icons.Default.AutoAwesome
                            HardwareMicType.PHONE_MIC -> Icons.Default.PhoneAndroid
                            HardwareMicType.BLUETOOTH_MIC -> Icons.Default.Bluetooth
                            HardwareMicType.WIRED_MIC -> Icons.Default.Headphones
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isCurrentSelected) ConsoleSurface else Color(0xFF090D18))
                                .border(
                                    1.dp,
                                    if (isCurrentSelected) NeonCyan else ConsoleBorder,
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable {
                                    onSelectMicType(mic.type)
                                    showFullDialog = false
                                }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (isCurrentSelected) NeonCyan.copy(alpha = 0.2f)
                                        else ConsoleSurfaceElevated
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = null,
                                    tint = if (isCurrentSelected) NeonCyan else TextSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = mic.name,
                                        color = if (isCurrentSelected) NeonCyan else TextPrimary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (mic.isConnected) {
                                        Text(
                                            text = "READY",
                                            color = SafeGreen,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                }
                                Text(
                                    text = mic.details,
                                    color = TextMuted,
                                    fontSize = 10.sp
                                )
                            }

                            if (isCurrentSelected) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Selected",
                                    tint = NeonCyan,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showFullDialog = false }) {
                    Text("DONE", color = NeonCyan, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}
