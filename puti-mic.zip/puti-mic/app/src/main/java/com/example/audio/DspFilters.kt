package com.example.audio

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tanh

/**
 * Standard second-order IIR Biquad filter implementation (Direct Form 1 / Transposed Form II)
 * for real-time low-latency audio equalization.
 */
class BiquadFilter {
    private var b0 = 1.0f
    private var b1 = 0.0f
    private var b2 = 0.0f
    private var a1 = 0.0f
    private var a2 = 0.0f

    private var x1 = 0.0f
    private var x2 = 0.0f
    private var y1 = 0.0f
    private var y2 = 0.0f

    fun reset() {
        x1 = 0f
        x2 = 0f
        y1 = 0f
        y2 = 0f
    }

    fun process(sample: Float): Float {
        val out = b0 * sample + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
        x2 = x1
        x1 = sample
        y2 = y1
        y1 = out
        return out
    }

    fun setLowShelf(sampleRate: Float, frequency: Float, gainDb: Float, q: Float = 0.707f) {
        val a = Math.pow(10.0, (gainDb / 40.0)).toFloat()
        val w0 = (2.0f * PI.toFloat() * frequency / sampleRate)
        val cosw0 = cos(w0)
        val sinw0 = sin(w0)
        val alpha = sinw0 / (2.0f * q)
        val twoSqrtAAlpha = 2.0f * sqrt(a) * alpha

        val a0 = (a + 1.0f) + (a - 1.0f) * cosw0 + twoSqrtAAlpha
        b0 = (a * ((a + 1.0f) - (a - 1.0f) * cosw0 + twoSqrtAAlpha)) / a0
        b1 = (2.0f * a * ((a - 1.0f) - (a + 1.0f) * cosw0)) / a0
        b2 = (a * ((a + 1.0f) - (a - 1.0f) * cosw0 - twoSqrtAAlpha)) / a0
        a1 = (-2.0f * ((a - 1.0f) + (a + 1.0f) * cosw0)) / a0
        a2 = ((a + 1.0f) + (a - 1.0f) * cosw0 - twoSqrtAAlpha) / a0
    }

    fun setHighShelf(sampleRate: Float, frequency: Float, gainDb: Float, q: Float = 0.707f) {
        val a = Math.pow(10.0, (gainDb / 40.0)).toFloat()
        val w0 = (2.0f * PI.toFloat() * frequency / sampleRate)
        val cosw0 = cos(w0)
        val sinw0 = sin(w0)
        val alpha = sinw0 / (2.0f * q)
        val twoSqrtAAlpha = 2.0f * sqrt(a) * alpha

        val a0 = (a + 1.0f) - (a - 1.0f) * cosw0 + twoSqrtAAlpha
        b0 = (a * ((a + 1.0f) + (a - 1.0f) * cosw0 + twoSqrtAAlpha)) / a0
        b1 = (-2.0f * a * ((a - 1.0f) + (a + 1.0f) * cosw0)) / a0
        b2 = (a * ((a + 1.0f) + (a - 1.0f) * cosw0 - twoSqrtAAlpha)) / a0
        a1 = (2.0f * ((a - 1.0f) - (a + 1.0f) * cosw0)) / a0
        a2 = ((a + 1.0f) - (a - 1.0f) * cosw0 - twoSqrtAAlpha) / a0
    }

    fun setPeakingEq(sampleRate: Float, frequency: Float, gainDb: Float, q: Float = 1.0f) {
        val a = Math.pow(10.0, (gainDb / 40.0)).toFloat()
        val w0 = (2.0f * PI.toFloat() * frequency / sampleRate)
        val cosw0 = cos(w0)
        val sinw0 = sin(w0)
        val alpha = sinw0 / (2.0f * q)

        val a0 = 1.0f + alpha / a
        b0 = (1.0f + alpha * a) / a0
        b1 = (-2.0f * cosw0) / a0
        b2 = (1.0f - alpha * a) / a0
        a1 = (-2.0f * cosw0) / a0
        a2 = (1.0f - alpha / a) / a0
    }

    fun setHighPass(sampleRate: Float, frequency: Float, q: Float = 0.707f) {
        val w0 = (2.0f * PI.toFloat() * frequency / sampleRate)
        val cosw0 = cos(w0)
        val sinw0 = sin(w0)
        val alpha = sinw0 / (2.0f * q)

        val a0 = 1.0f + alpha
        b0 = ((1.0f + cosw0) / 2.0f) / a0
        b1 = (-(1.0f + cosw0)) / a0
        b2 = ((1.0f + cosw0) / 2.0f) / a0
        a1 = (-2.0f * cosw0) / a0
        a2 = (1.0f - alpha) / a0
    }

    fun setNotch(sampleRate: Float, frequency: Float, q: Float = 5.0f) {
        val w0 = (2.0f * PI.toFloat() * frequency / sampleRate)
        val cosw0 = cos(w0)
        val sinw0 = sin(w0)
        val alpha = sinw0 / (2.0f * q)

        val a0 = 1.0f + alpha
        b0 = 1.0f / a0
        b1 = (-2.0f * cosw0) / a0
        b2 = 1.0f / a0
        a1 = (-2.0f * cosw0) / a0
        a2 = (1.0f - alpha) / a0
    }
}

/**
 * Noise Gate to suppress microphone room noise/hiss when quiet.
 */
class NoiseGate(
    private val thresholdDb: Float = -45f,
    private val attackMs: Float = 5f,
    private val releaseMs: Float = 60f,
    sampleRate: Float = 44100f
) {
    private val thresholdAmp = Math.pow(10.0, (thresholdDb / 20.0)).toFloat()
    private val attackCoeff = Math.exp((-1.0 / (attackMs * 0.001 * sampleRate))).toFloat()
    private val releaseCoeff = Math.exp((-1.0 / (releaseMs * 0.001 * sampleRate))).toFloat()
    private var currentGain = 1.0f
    private var envelope = 0.0f

    fun reset() {
        currentGain = 1.0f
        envelope = 0.0f
    }

    fun process(sample: Float): Float {
        val absSample = kotlin.math.abs(sample)
        envelope = if (absSample > envelope) {
            attackCoeff * envelope + (1f - attackCoeff) * absSample
        } else {
            releaseCoeff * envelope + (1f - releaseCoeff) * absSample
        }

        val targetGain = if (envelope > thresholdAmp) 1.0f else {
            val ratio = (envelope / thresholdAmp).coerceIn(0.05f, 1.0f)
            ratio * ratio // Smooth quadratic expansion curve
        }

        currentGain = 0.9f * currentGain + 0.1f * targetGain
        return sample * currentGain
    }
}

/**
 * Anti-Feedback Notch and Phase Shifter to dampen acoustic howling loops.
 */
class FeedbackSuppressor(private val sampleRate: Float = 44100f) {
    private val notch1 = BiquadFilter()
    private val notch2 = BiquadFilter()
    private val notch3 = BiquadFilter()

    init {
        // High risk howling frequencies in typical phone mics/speakers: 1.8kHz, 3.2kHz, 4.5kHz
        notch1.setNotch(sampleRate, 1850f, 4.0f)
        notch2.setNotch(sampleRate, 3200f, 4.5f)
        notch3.setNotch(sampleRate, 4400f, 5.0f)
    }

    fun reset() {
        notch1.reset()
        notch2.reset()
        notch3.reset()
    }

    fun process(sample: Float): Float {
        val s1 = notch1.process(sample)
        val s2 = notch2.process(s1)
        return notch3.process(s2)
    }
}

/**
 * Studio-grade soft-knee saturator and peak limiter.
 * Allows massive digital amplification (up to 10,000%) without harsh square-wave tearing.
 */
object AudioLimiter {
    private const val CEILING = 0.98f

    fun applySoftLimiter(sample: Float, limiterEnabled: Boolean = true): Float {
        if (!limiterEnabled) {
            return sample.coerceIn(-1.0f, 1.0f)
        }

        val absVal = kotlin.math.abs(sample)
        return if (absVal <= 0.6f) {
            sample
        } else {
            // Smooth hyperbolic tangent soft-knee saturation
            val sign = if (sample >= 0f) 1.0f else -1.0f
            val normalized = (absVal - 0.6f) / 0.4f
            val compressed = 0.6f + 0.38f * tanh(normalized)
            (sign * compressed * CEILING).coerceIn(-1.0f, 1.0f)
        }
    }
}
