package com.example.audio

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Build
import android.os.Process
import android.util.Log
import com.example.data.AudioLevels
import com.example.data.DspSettings
import com.example.data.MicTestResult
import com.example.data.MicTestState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class MicTestEngine(
    private val context: Context,
    private val audioRouter: AudioRouter
) {
    private val TAG = "MicTestEngine"
    private val sampleRate = 44100
    private val channelConfigIn = AudioFormat.CHANNEL_IN_MONO
    private val channelConfigOut = AudioFormat.CHANNEL_OUT_MONO
    private val audioFormat = AudioFormat.ENCODING_PCM_16BIT

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val engineScope = CoroutineScope(Dispatchers.Default)

    private val _testState = MutableStateFlow(MicTestState.IDLE)
    val testState: StateFlow<MicTestState> = _testState.asStateFlow()

    private val _recordingProgress = MutableStateFlow(0f) // 0.0 to 1.0
    val recordingProgress: StateFlow<Float> = _recordingProgress.asStateFlow()

    private val _playbackProgress = MutableStateFlow(0f) // 0.0 to 1.0
    val playbackProgress: StateFlow<Float> = _playbackProgress.asStateFlow()

    private val _latestTestResult = MutableStateFlow<MicTestResult?>(null)
    val latestTestResult: StateFlow<MicTestResult?> = _latestTestResult.asStateFlow()

    private val _liveLoopbackLevels = MutableStateFlow(AudioLevels())
    val liveLoopbackLevels: StateFlow<AudioLevels> = _liveLoopbackLevels.asStateFlow()

    private val _isPlayingBoosted = MutableStateFlow(true)
    val isPlayingBoosted: StateFlow<Boolean> = _isPlayingBoosted.asStateFlow()

    // Buffers for recorded voice test
    private var rawRecordedSamples: ShortArray? = null
    private var boostedRecordedSamples: ShortArray? = null
    private var totalRecordedFrames = 0

    @Volatile
    private var isRecording = false

    @Volatile
    private var isPlaying = false

    @Volatile
    private var isLiveLoopbackRunning = false

    private var activeAudioRecord: AudioRecord? = null
    private var activeAudioTrack: AudioTrack? = null
    private var workerThread: Thread? = null

    // DSP components for test processing
    private val bassFilter = BiquadFilter()
    private val trebleFilter = BiquadFilter()
    private val vocalPresenceFilter = BiquadFilter()
    private val highPassFilter = BiquadFilter()
    private val noiseGate = NoiseGate(sampleRate = sampleRate.toFloat())
    private val feedbackSuppressor = FeedbackSuppressor(sampleRate = sampleRate.toFloat())

    /**
     * Start recording a voice test sample (typically 5 to 10 seconds).
     */
    @SuppressLint("MissingPermission")
    fun startVoiceRecordTest(
        settings: DspSettings,
        durationSeconds: Int = 5
    ) {
        if (_testState.value != MicTestState.IDLE) {
            stopAll()
        }

        val totalExpectedSamples = sampleRate * durationSeconds
        val rawBuffer = ShortArray(totalExpectedSamples)
        val boostedBuffer = ShortArray(totalExpectedSamples)

        // Configure filters for this test run
        bassFilter.setLowShelf(sampleRate.toFloat(), 180f, settings.bassGainDb)
        trebleFilter.setHighShelf(sampleRate.toFloat(), 5000f, settings.trebleGainDb)
        vocalPresenceFilter.setPeakingEq(sampleRate.toFloat(), 2800f, if (settings.voiceClarityEnabled) 6.0f else 0.0f, 1.2f)
        highPassFilter.setHighPass(sampleRate.toFloat(), 80f)
        noiseGate.reset()
        feedbackSuppressor.reset()

        val minRecordBufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfigIn, audioFormat)
        val bufferSize = max(minRecordBufferSize * 2, 2048)

        val audioSource = settings.audioInputSource.mediaRecorderSource
        var record: AudioRecord? = null
        try {
            record = AudioRecord(audioSource, sampleRate, channelConfigIn, audioFormat, bufferSize)
        } catch (e: Exception) {
            Log.w(TAG, "AudioRecord init fallback to MIC: ${e.message}")
        }

        if (record == null || record.state != AudioRecord.STATE_INITIALIZED) {
            record?.release()
            record = AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, channelConfigIn, audioFormat, bufferSize)
        }

        if (record.state != AudioRecord.STATE_INITIALIZED) {
            Log.e(TAG, "Failed initializing test AudioRecord")
            record.release()
            return
        }

        activeAudioRecord = record
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val prefDevice = audioRouter.getPreferredInputDevice(settings.hardwareMicType)
            if (prefDevice != null) {
                record.preferredDevice = prefDevice
            }
        }

        try {
            record.startRecording()
        } catch (e: Exception) {
            Log.e(TAG, "Cannot start recording: ${e.message}")
            record.release()
            return
        }

        isRecording = true
        _testState.value = MicTestState.RECORDING
        _recordingProgress.value = 0f

        val digitalGain = (settings.boostPercentage / 100.0f) * (if (settings.isSpeakerBoostEnabled) 1.414f else 1.0f)
        val waveformSnapshots = mutableListOf<Float>()

        workerThread = Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val chunk = ShortArray(256)
            var totalRead = 0
            var clippingDetected = false
            var peakAmplitude = 0f
            var rawSumSq = 0.0
            var boostedSumSq = 0.0
            var minSliceRms = 1.0f

            while (isRecording && totalRead < totalExpectedSamples) {
                val toRead = min(chunk.size, totalExpectedSamples - totalRead)
                val readCount = record.read(chunk, 0, toRead)
                if (readCount <= 0) continue

                var sliceSumSq = 0.0
                for (i in 0 until readCount) {
                    val rawSample = chunk[i]
                    val rawNorm = rawSample / 32768.0f
                    rawBuffer[totalRead + i] = rawSample

                    rawSumSq += (rawNorm * rawNorm).toDouble()
                    sliceSumSq += (rawNorm * rawNorm).toDouble()
                    peakAmplitude = max(peakAmplitude, abs(rawNorm))

                    // Apply DSP & Gain
                    var processed = highPassFilter.process(rawNorm)
                    if (settings.noiseReductionEnabled) processed = noiseGate.process(processed)
                    if (settings.voiceClarityEnabled) processed = vocalPresenceFilter.process(processed)
                    if (settings.bassGainDb != 0f) processed = bassFilter.process(processed)
                    if (settings.trebleGainDb != 0f) processed = trebleFilter.process(processed)
                    if (settings.feedbackSuppressionEnabled) processed = feedbackSuppressor.process(processed)

                    processed *= digitalGain

                    if (abs(processed) > 0.98f) {
                        clippingDetected = true
                    }
                    val limited = AudioLimiter.applySoftLimiter(processed, settings.limiterEnabled)
                    boostedSumSq += (limited * limited).toDouble()

                    val pcmBoosted = (limited * 32767.0f).toInt().coerceIn(-32768, 32767)
                    boostedBuffer[totalRead + i] = pcmBoosted.toShort()
                }

                totalRead += readCount
                val currentProgress = totalRead.toFloat() / totalExpectedSamples.toFloat()
                _recordingProgress.value = currentProgress

                // Estimate noise floor from lowest non-zero energy slice
                val sliceRms = sqrt(sliceSumSq / readCount).toFloat()
                if (sliceRms in 0.0001f..<minSliceRms) {
                    minSliceRms = sliceRms
                }

                // Sample waveform points
                if (totalRead % (totalExpectedSamples / 48) < readCount) {
                    waveformSnapshots.add(peakAmplitude)
                }
            }

            // Finish recording and compute final test analytics
            try {
                record.stop()
                record.release()
            } catch (_: Exception) {}
            activeAudioRecord = null
            isRecording = false

            totalRecordedFrames = totalRead
            rawRecordedSamples = rawBuffer.copyOfRange(0, totalRead)
            boostedRecordedSamples = boostedBuffer.copyOfRange(0, totalRead)

            val rawRms = if (totalRead > 0) sqrt(rawSumSq / totalRead).toFloat() else 0f
            val boostedRms = if (totalRead > 0) sqrt(boostedSumSq / totalRead).toFloat() else 0f

            val rawDb = if (rawRms > 0.0001f) (20.0f * log10(rawRms)).coerceIn(-60f, 0f) else -60f
            val boostedDb = if (boostedRms > 0.0001f) (20.0f * log10(boostedRms)).coerceIn(-60f, 6f) else -60f
            val peakDb = if (peakAmplitude > 0.0001f) (20.0f * log10(peakAmplitude)).coerceIn(-60f, 0f) else -60f
            val noiseFloorDb = if (minSliceRms > 0.00001f) (20.0f * log10(minSliceRms)).coerceIn(-60f, -10f) else -55f

            val snr = (boostedDb - noiseFloorDb).coerceIn(0f, 60f)

            // Clarity Score calculation
            var clarity = 75
            if (snr > 20f) clarity += 15
            if (settings.voiceClarityEnabled) clarity += 10
            if (clippingDetected && !settings.limiterEnabled) clarity -= 20
            if (rawDb < -40f) clarity -= 15 // Very quiet input
            clarity = clarity.coerceIn(20, 100)

            val activeHw = audioRouter.activeMicStatus.value.name

            val verdict = when {
                boostedDb >= -12f && snr >= 20f -> "🏆 Studio Quality: Crystal clear voice with robust volume & zero distortion."
                boostedDb >= -18f -> "✅ Optimal Voice Chat: Loud and crisp, ideal for Hapi, Masti & PK Rooms."
                rawDb < -35f -> "⚠️ Low Mic Input: Speak closer to the mic or increase boost gain slider."
                clippingDetected -> "⚡ High Saturation: Hardware limiter active to protect output speakers."
                else -> "👍 Good Voice Presence: Audio levels ready for voice communication."
            }

            // Downsample waveform to exactly 48 points
            val finalWaveform = FloatArray(48)
            val step = max(1, totalRead / 48)
            for (k in 0 until 48) {
                val idx = min(k * step, totalRead - 1)
                finalWaveform[k] = if (idx >= 0) abs(boostedBuffer[idx] / 32768.0f) else 0f
            }

            val result = MicTestResult(
                durationSeconds = totalRead.toFloat() / sampleRate.toFloat(),
                rawRmsDb = rawDb,
                boostedRmsDb = boostedDb,
                peakDb = peakDb,
                noiseFloorDb = noiseFloorDb,
                snrDb = snr,
                clarityScore = clarity,
                isClippingDetected = clippingDetected,
                activeHardwareName = activeHw,
                evaluationVerdict = verdict,
                recordedWaveform = finalWaveform
            )

            _latestTestResult.value = result
            _testState.value = MicTestState.IDLE
            _recordingProgress.value = 1.0f

            // Auto-play the test result immediately so the user hears their voice!
            playRecordedVoiceTest(useBoosted = true)

        }.apply {
            name = "PutiMicTestRecordThread"
            start()
        }
    }

    /**
     * Playback the recorded voice test so the user can listen to their voice.
     * [useBoosted] toggles between the amplified DSP audio and the raw microphone recording.
     */
    fun playRecordedVoiceTest(useBoosted: Boolean = true) {
        val samplesToPlay = if (useBoosted) boostedRecordedSamples else rawRecordedSamples
        if (samplesToPlay == null || samplesToPlay.isEmpty()) {
            Log.w(TAG, "No recorded test samples to play")
            return
        }

        if (isPlaying) {
            stopPlayback()
        }

        _isPlayingBoosted.value = useBoosted
        _testState.value = MicTestState.PLAYING
        _playbackProgress.value = 0f
        isPlaying = true

        val minTrackBufferSize = AudioTrack.getMinBufferSize(sampleRate, channelConfigOut, audioFormat)
        val trackBufferSize = max(minTrackBufferSize * 2, 2048)

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()

        val audioFormatSpec = AudioFormat.Builder()
            .setEncoding(audioFormat)
            .setSampleRate(sampleRate)
            .setChannelMask(channelConfigOut)
            .build()

        val track = AudioTrack(
            audioAttributes,
            audioFormatSpec,
            trackBufferSize,
            AudioTrack.MODE_STREAM,
            AudioManager.AUDIO_SESSION_ID_GENERATE
        )

        if (track.state != AudioTrack.STATE_INITIALIZED) {
            Log.e(TAG, "AudioTrack init failed for playback")
            track.release()
            _testState.value = MicTestState.IDLE
            isPlaying = false
            return
        }

        activeAudioTrack = track
        track.play()

        workerThread = Thread {
            val totalSamples = samplesToPlay.size
            var offset = 0
            val chunkSize = 512

            while (isPlaying && offset < totalSamples) {
                val count = min(chunkSize, totalSamples - offset)
                track.write(samplesToPlay, offset, count)
                offset += count

                _playbackProgress.value = offset.toFloat() / totalSamples.toFloat()
            }

            try {
                track.stop()
                track.release()
            } catch (_: Exception) {}
            activeAudioTrack = null
            isPlaying = false
            _testState.value = MicTestState.IDLE
            _playbackProgress.value = 1.0f
        }.apply {
            name = "PutiMicTestPlaybackThread"
            start()
        }
    }

    fun stopPlayback() {
        isPlaying = false
        try {
            activeAudioTrack?.stop()
            activeAudioTrack?.release()
        } catch (_: Exception) {}
        activeAudioTrack = null
        if (_testState.value == MicTestState.PLAYING) {
            _testState.value = MicTestState.IDLE
        }
    }

    /**
     * Start live direct sidetone/loopback test (Hear your voice live in real time).
     */
    @SuppressLint("MissingPermission")
    fun startLiveLoopback(settings: DspSettings) {
        if (_testState.value != MicTestState.IDLE) {
            stopAll()
        }

        val minRecordBufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfigIn, audioFormat)
        val minTrackBufferSize = AudioTrack.getMinBufferSize(sampleRate, channelConfigOut, audioFormat)

        val recordBufferSize = max(minRecordBufferSize * 2, 2048)
        val trackBufferSize = max(minTrackBufferSize * 2, 2048)

        var record: AudioRecord? = null
        try {
            record = AudioRecord(
                settings.audioInputSource.mediaRecorderSource,
                sampleRate,
                channelConfigIn,
                audioFormat,
                recordBufferSize
            )
        } catch (_: Exception) {}

        if (record == null || record.state != AudioRecord.STATE_INITIALIZED) {
            record?.release()
            record = AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, channelConfigIn, audioFormat, recordBufferSize)
        }

        if (record.state != AudioRecord.STATE_INITIALIZED) {
            Log.e(TAG, "Loopback record init failed")
            record.release()
            return
        }

        val track = AudioTrack(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .setFlags(AudioAttributes.FLAG_LOW_LATENCY)
                .build(),
            AudioFormat.Builder()
                .setEncoding(audioFormat)
                .setSampleRate(sampleRate)
                .setChannelMask(channelConfigOut)
                .build(),
            trackBufferSize,
            AudioTrack.MODE_STREAM,
            AudioManager.AUDIO_SESSION_ID_GENERATE
        )

        if (track.state != AudioTrack.STATE_INITIALIZED) {
            record.release()
            track.release()
            return
        }

        activeAudioRecord = record
        activeAudioTrack = track

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            audioRouter.getPreferredInputDevice(settings.hardwareMicType)?.let {
                record.preferredDevice = it
            }
        }

        record.startRecording()
        track.play()

        isLiveLoopbackRunning = true
        _testState.value = MicTestState.LIVE_MONITOR

        bassFilter.setLowShelf(sampleRate.toFloat(), 180f, settings.bassGainDb)
        trebleFilter.setHighShelf(sampleRate.toFloat(), 5000f, settings.trebleGainDb)
        vocalPresenceFilter.setPeakingEq(sampleRate.toFloat(), 2800f, if (settings.voiceClarityEnabled) 6.0f else 0.0f, 1.2f)
        highPassFilter.setHighPass(sampleRate.toFloat(), 80f)
        noiseGate.reset()
        feedbackSuppressor.reset()

        val digitalGain = (settings.boostPercentage / 100.0f) * (if (settings.isSpeakerBoostEnabled) 1.414f else 1.0f)

        workerThread = Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val chunkSize = 256
            val inBuf = ShortArray(chunkSize)
            val outBuf = ShortArray(chunkSize)
            val waveform = FloatArray(32)
            val frequencyBands = FloatArray(16)
            var frame = 0

            while (isLiveLoopbackRunning && activeAudioRecord != null && activeAudioTrack != null) {
                val read = activeAudioRecord!!.read(inBuf, 0, chunkSize)
                if (read <= 0) continue

                var inSum = 0.0
                var outSum = 0.0
                var inPeak = 0.0f
                var outPeak = 0.0f
                var isClip = false

                for (i in 0 until read) {
                    val raw = inBuf[i] / 32768.0f
                    inSum += (raw * raw).toDouble()
                    inPeak = max(inPeak, abs(raw))

                    var processed = highPassFilter.process(raw)
                    if (settings.noiseReductionEnabled) processed = noiseGate.process(processed)
                    if (settings.voiceClarityEnabled) processed = vocalPresenceFilter.process(processed)
                    if (settings.bassGainDb != 0f) processed = bassFilter.process(processed)
                    if (settings.trebleGainDb != 0f) processed = trebleFilter.process(processed)
                    if (settings.feedbackSuppressionEnabled) processed = feedbackSuppressor.process(processed)

                    processed *= digitalGain
                    if (abs(processed) > 0.98f) isClip = true
                    val limited = AudioLimiter.applySoftLimiter(processed, settings.limiterEnabled)

                    outSum += (limited * limited).toDouble()
                    outPeak = max(outPeak, abs(limited))

                    val pcm = (limited * 32767.0f).toInt().coerceIn(-32768, 32767)
                    outBuf[i] = pcm.toShort()
                }

                activeAudioTrack?.write(outBuf, 0, read)

                frame++
                if (frame % 6 == 0) {
                    val inRms = sqrt(inSum / read).toFloat()
                    val outRms = sqrt(outSum / read).toFloat()
                    val inDb = if (inRms > 0.0001f) (20.0f * log10(inRms)).coerceIn(-60f, 0f) else -60f
                    val outDb = if (outRms > 0.0001f) (20.0f * log10(outRms)).coerceIn(-60f, 6f) else -60f

                    for (k in 0 until 32) {
                        val idx = min(k * (read / 32), read - 1)
                        waveform[k] = outBuf[idx] / 32768.0f
                    }
                    for (b in 0 until 16) {
                        frequencyBands[b] = (outPeak * (0.5f + 0.5f * abs(kotlin.math.sin(frame * 0.15f + b * 0.4f)))).coerceIn(0.02f, 1f)
                    }

                    _liveLoopbackLevels.value = AudioLevels(
                        inputRmsDb = inDb,
                        inputPeak = inPeak,
                        outputRmsDb = outDb,
                        outputPeak = outPeak,
                        isClipping = isClip,
                        waveform = waveform.copyOf(),
                        frequencyBands = frequencyBands.copyOf()
                    )
                }
            }

            try {
                record.stop()
                record.release()
            } catch (_: Exception) {}
            try {
                track.stop()
                track.release()
            } catch (_: Exception) {}

            activeAudioRecord = null
            activeAudioTrack = null
            isLiveLoopbackRunning = false
            _testState.value = MicTestState.IDLE
            _liveLoopbackLevels.value = AudioLevels()
        }.apply {
            name = "PutiMicLiveLoopbackThread"
            start()
        }
    }

    fun stopLiveLoopback() {
        isLiveLoopbackRunning = false
        try {
            activeAudioRecord?.stop()
            activeAudioRecord?.release()
        } catch (_: Exception) {}
        try {
            activeAudioTrack?.stop()
            activeAudioTrack?.release()
        } catch (_: Exception) {}
        activeAudioRecord = null
        activeAudioTrack = null
        if (_testState.value == MicTestState.LIVE_MONITOR) {
            _testState.value = MicTestState.IDLE
        }
    }

    fun stopAll() {
        isRecording = false
        isPlaying = false
        isLiveLoopbackRunning = false
        try {
            activeAudioRecord?.stop()
            activeAudioRecord?.release()
        } catch (_: Exception) {}
        try {
            activeAudioTrack?.stop()
            activeAudioTrack?.release()
        } catch (_: Exception) {}
        activeAudioRecord = null
        activeAudioTrack = null
        _testState.value = MicTestState.IDLE
    }

    fun release() {
        stopAll()
        rawRecordedSamples = null
        boostedRecordedSamples = null
    }
}
