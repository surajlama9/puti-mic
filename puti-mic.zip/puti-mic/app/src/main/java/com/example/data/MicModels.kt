package com.example.data

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.DangerRed
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.FieryOrange
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.SafeGreen
import com.example.ui.theme.WarningYellow

enum class BoostMode(
    val title: String,
    val rangeText: String,
    val minPercentage: Int,
    val maxPercentage: Int,
    val defaultPercentage: Int,
    val accentColor: Color,
    val requiresWarning: Boolean,
    val description: String
) {
    NORMAL(
        title = "NORMAL",
        rangeText = "100–200%",
        minPercentage = 100,
        maxPercentage = 200,
        defaultPercentage = 150,
        accentColor = SafeGreen,
        requiresWarning = false,
        description = "Clean, natural vocal amplification for conversations and lectures."
    ),
    STRONG(
        title = "STRONG",
        rangeText = "200–500%",
        minPercentage = 200,
        maxPercentage = 500,
        defaultPercentage = 350,
        accentColor = NeonCyan,
        requiresWarning = false,
        description = "High clarity boost for presentations, tour guides, and small rooms."
    ),
    ULTRA(
        title = "ULTRA",
        rangeText = "500–2,000%",
        minPercentage = 500,
        maxPercentage = 2000,
        defaultPercentage = 1000,
        accentColor = WarningYellow,
        requiresWarning = false,
        description = "Powerful digital gain for distant speech, ASMR, and large areas."
    ),
    EXTREME(
        title = "EXTREME",
        rangeText = "2,000–5,000%",
        minPercentage = 2000,
        maxPercentage = 5000,
        defaultPercentage = 3000,
        accentColor = FieryOrange,
        requiresWarning = true,
        description = "Caution: Very high digital boost. Use headphones or place phone away from speaker to avoid feedback squeal."
    ),
    PUTI_MAX(
        title = "PUTI MAX",
        rangeText = "5,000–10,000%",
        minPercentage = 5000,
        maxPercentage = 10000,
        defaultPercentage = 10000,
        accentColor = NeonPink,
        requiresWarning = true,
        description = "MAXIMUM UI TARGET: Extreme digital pre-amplification. Hardware output is strictly limited by phone speaker and OS protection to avoid hardware damage."
    );

    companion object {
        fun fromPercentage(percentage: Int): BoostMode {
            return when {
                percentage < 200 -> NORMAL
                percentage < 500 -> STRONG
                percentage < 2000 -> ULTRA
                percentage < 5000 -> EXTREME
                else -> PUTI_MAX
            }
        }
    }
}

enum class AudioRoute(val displayName: String, val iconName: String) {
    SPEAKER("Phone Loudspeaker", "speaker"),
    EARPIECE("Earpiece Receiver", "phone_in_talk"),
    WIRED_HEADSET("Wired Headphones / Aux", "headphones"),
    BLUETOOTH("Bluetooth Device", "bluetooth")
}

/**
 * Hardware microphone input capture device options (All-in-One, Built-in, Bluetooth, Wired/USB).
 */
enum class HardwareMicType(
    val displayName: String,
    val shortName: String,
    val subtitle: String,
    val iconName: String,
    val tag: String
) {
    AUTO(
        displayName = "All-In-One (Auto Smart)",
        shortName = "Auto All-In-One",
        subtitle = "Auto switches between Bluetooth, Wired & Phone mic",
        iconName = "auto",
        tag = "AUTO"
    ),
    PHONE_MIC(
        displayName = "Device Built-in Mic",
        shortName = "Phone Mic",
        subtitle = "Internal phone microphone (Bottom/Front mic)",
        iconName = "phone_mic",
        tag = "DEVICE"
    ),
    BLUETOOTH_MIC(
        displayName = "Bluetooth Mic (Wireless)",
        shortName = "Bluetooth Mic",
        subtitle = "AirPods, Galaxy Buds, Wireless Lapel & Headsets",
        iconName = "bluetooth",
        tag = "BT"
    ),
    WIRED_MIC(
        displayName = "Wired / USB Mic",
        shortName = "Wired / USB Mic",
        subtitle = "3.5mm Headset, USB-C Lavalier, Aux / Interface",
        iconName = "wired",
        tag = "WIRED"
    )
}

data class MicDeviceStatus(
    val type: HardwareMicType,
    val name: String,
    val isConnected: Boolean,
    val isActive: Boolean,
    val deviceId: Int = -1,
    val details: String = ""
)

/**
 * Audio hardware capture source for maximum compatibility with VoIP & Voice Chat apps.
 */
enum class AudioInputSource(
    val displayName: String,
    val mediaRecorderSource: Int,
    val description: String,
    val isVoipRecommended: Boolean
) {
    VOICE_COMMUNICATION(
        displayName = "VoIP Communication (Hapi / Masti / IMO)",
        mediaRecorderSource = 7, // MediaRecorder.AudioSource.VOICE_COMMUNICATION
        description = "Recommended for voice chat apps. Enables OS-level Acoustic Echo Cancellation and simultaneous VoIP routing.",
        isVoipRecommended = true
    ),
    MIC(
        displayName = "Standard Hardware Mic",
        mediaRecorderSource = 1, // MediaRecorder.AudioSource.MIC
        description = "Direct hardware capture. Best for general public speaking, megaphone use, and standalone amplification.",
        isVoipRecommended = false
    ),
    VOICE_RECOGNITION(
        displayName = "Voice Clarity Stream",
        mediaRecorderSource = 6, // MediaRecorder.AudioSource.VOICE_RECOGNITION
        description = "Clean vocal capture with ambient noise reduction pre-applied by Android HAL.",
        isVoipRecommended = true
    ),
    CAMCORDER(
        displayName = "High-Gain Ambient (Camcorder)",
        mediaRecorderSource = 5, // MediaRecorder.AudioSource.CAMCORDER
        description = "Wide-range multi-mic capture with high sensitivity for distant voices.",
        isVoipRecommended = false
    ),
    UNPROCESSED(
        displayName = "Raw Studio (Unprocessed)",
        mediaRecorderSource = 9, // MediaRecorder.AudioSource.UNPROCESSED
        description = "Pure bit-accurate stream without Android hardware pre-filtering. Minimum latency.",
        isVoipRecommended = false
    )
}

/**
 * Audio focus handling behavior when voice chat apps or media player start playing sound.
 */
enum class AudioFocusPolicy(
    val displayName: String,
    val description: String
) {
    IGNORE_FOCUS_LOSS(
        displayName = "Continuous Boost (Never Pause)",
        description = "Puti Mic keeps amplifying in the background even when Hapi, Masti, or IMO takes audio focus."
    ),
    DUCK_ON_LOSS(
        displayName = "Auto Ducking",
        description = "Slightly lowers Puti Mic volume when other apps or incoming notifications play."
    ),
    STRICT(
        displayName = "Pause on Call",
        description = "Pauses live amplifier during incoming phone calls."
    )
}

/**
 * Optimized voice chat profiles tailored for popular social audio apps.
 */
enum class VoiceChatProfile(
    val id: String,
    val title: String,
    val subtitle: String,
    val packageName: String,
    val recommendedBoost: Int,
    val recommendedSource: AudioInputSource,
    val echoCancellation: Boolean,
    val noiseReduction: Boolean,
    val voiceClarity: Boolean,
    val feedbackSuppression: Boolean,
    val lowLatency: Boolean,
    val bassGainDb: Float,
    val trebleGainDb: Float,
    val accentColor: Color,
    val tips: String
) {
    HAPI(
        id = "hapi",
        title = "Hapi Voice Rooms",
        subtitle = "Tuned for Hapi Party Rooms, Live Gifting & PK Battles",
        packageName = "com.hapi.voice",
        recommendedBoost = 350,
        recommendedSource = AudioInputSource.VOICE_COMMUNICATION,
        echoCancellation = true,
        noiseReduction = true,
        voiceClarity = true,
        feedbackSuppression = true,
        lowLatency = true,
        bassGainDb = 2.0f,
        trebleGainDb = 3.5f,
        accentColor = NeonCyan,
        tips = "Use Floating Bubble while inside Hapi party rooms to adjust boost on the fly without minimizing the live room."
    ),
    MASTI(
        id = "masti",
        title = "Masti Live & Chat",
        subtitle = "Optimized for Masti Voice Parties, Karaoke & Mic Hosting",
        packageName = "com.masti.live",
        recommendedBoost = 400,
        recommendedSource = AudioInputSource.VOICE_COMMUNICATION,
        echoCancellation = true,
        noiseReduction = true,
        voiceClarity = true,
        feedbackSuppression = true,
        lowLatency = true,
        bassGainDb = 3.0f,
        trebleGainDb = 4.0f,
        accentColor = ElectricViolet,
        tips = "Turn on Anti-Feedback to avoid howling when the host or friends talk simultaneously in Masti."
    ),
    IMO(
        id = "imo",
        title = "IMO Calls & Rooms",
        subtitle = "Crystal-clear HD voice boost for IMO voice & video calls",
        packageName = "com.imo.android.imoim",
        recommendedBoost = 250,
        recommendedSource = AudioInputSource.VOICE_COMMUNICATION,
        echoCancellation = true,
        noiseReduction = true,
        voiceClarity = true,
        feedbackSuppression = true,
        lowLatency = true,
        bassGainDb = 0.5f,
        trebleGainDb = 2.0f,
        accentColor = SafeGreen,
        tips = "Acoustic Echo Cancellation is pre-enabled so the other party won't hear their own voice echo during IMO calls."
    ),
    DISCORD(
        id = "discord",
        title = "Discord & Gaming",
        subtitle = "Ultra low latency voice chat for gaming & Discord servers",
        packageName = "com.discord",
        recommendedBoost = 200,
        recommendedSource = AudioInputSource.VOICE_COMMUNICATION,
        echoCancellation = true,
        noiseReduction = true,
        voiceClarity = true,
        feedbackSuppression = false,
        lowLatency = true,
        bassGainDb = 1.0f,
        trebleGainDb = 2.5f,
        accentColor = NeonCyan,
        tips = "Ultra-low latency buffer (<6ms) ensures immediate game callouts without lag."
    ),
    WHATSAPP_TELEGRAM(
        id = "messaging",
        title = "WhatsApp & Telegram",
        subtitle = "Enhanced voice messages & group VoIP calls",
        packageName = "com.whatsapp",
        recommendedBoost = 250,
        recommendedSource = AudioInputSource.VOICE_COMMUNICATION,
        echoCancellation = true,
        noiseReduction = true,
        voiceClarity = true,
        feedbackSuppression = true,
        lowLatency = true,
        bassGainDb = 0f,
        trebleGainDb = 2.0f,
        accentColor = SafeGreen,
        tips = "Great for noisy outdoor calls or low-volume earpieces."
    ),
    PK_BATTLE_LOUD(
        id = "pk_battle",
        title = "PK Battle & Loud Hype",
        subtitle = "High-energy extreme voice boost with brickwall limiting",
        packageName = "",
        recommendedBoost = 1200,
        recommendedSource = AudioInputSource.VOICE_COMMUNICATION,
        echoCancellation = true,
        noiseReduction = true,
        voiceClarity = true,
        feedbackSuppression = true,
        lowLatency = true,
        bassGainDb = 4.0f,
        trebleGainDb = 5.0f,
        accentColor = NeonPink,
        tips = "Hardware Limiter ensures maximum voice loudness without distorted sound or blown speakers during PK battles."
    );

    companion object {
        fun fromId(id: String): VoiceChatProfile = values().find { it.id == id } ?: HAPI
    }
}

data class DspSettings(
    val boostPercentage: Int = 150,
    val isMuted: Boolean = false,
    val isSpeakerBoostEnabled: Boolean = false,
    val noiseReductionEnabled: Boolean = true,
    val echoCancellationEnabled: Boolean = true,
    val feedbackSuppressionEnabled: Boolean = true,
    val voiceClarityEnabled: Boolean = true,
    val lowLatencyMode: Boolean = true,
    val autoGainControl: Boolean = false,
    val limiterEnabled: Boolean = true,
    val bassGainDb: Float = 0f,
    val trebleGainDb: Float = 0f,
    val audioInputSource: AudioInputSource = AudioInputSource.VOICE_COMMUNICATION,
    val audioFocusPolicy: AudioFocusPolicy = AudioFocusPolicy.IGNORE_FOCUS_LOSS,
    val activeProfileId: String = "hapi",
    val floatingOverlayEnabled: Boolean = false,
    val hardwareMicType: HardwareMicType = HardwareMicType.AUTO
)

data class AudioLevels(
    val inputRmsDb: Float = -60f,
    val inputPeak: Float = 0f,
    val outputRmsDb: Float = -60f,
    val outputPeak: Float = 0f,
    val isClipping: Boolean = false,
    val waveform: FloatArray = FloatArray(32),
    val frequencyBands: FloatArray = FloatArray(16)
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is AudioLevels) return false
        if (inputRmsDb != other.inputRmsDb) return false
        if (inputPeak != other.inputPeak) return false
        if (outputRmsDb != other.outputRmsDb) return false
        if (outputPeak != other.outputPeak) return false
        if (isClipping != other.isClipping) return false
        if (!waveform.contentEquals(other.waveform)) return false
        return frequencyBands.contentEquals(other.frequencyBands)
    }

    override fun hashCode(): Int {
        var result = inputRmsDb.hashCode()
        result = 31 * result + inputPeak.hashCode()
        result = 31 * result + outputRmsDb.hashCode()
        result = 31 * result + outputPeak.hashCode()
        result = 31 * result + isClipping.hashCode()
        result = 31 * result + waveform.contentHashCode()
        result = 31 * result + frequencyBands.contentHashCode()
        return result
    }
}

/**
 * Microphone test system models
 */
enum class MicTestState {
    IDLE,
    RECORDING,
    PLAYING,
    LIVE_MONITOR
}

data class MicTestResult(
    val durationSeconds: Float = 0f,
    val rawRmsDb: Float = -60f,
    val boostedRmsDb: Float = -60f,
    val peakDb: Float = -60f,
    val noiseFloorDb: Float = -60f,
    val snrDb: Float = 0f,
    val clarityScore: Int = 0, // 0 to 100%
    val isClippingDetected: Boolean = false,
    val activeHardwareName: String = "",
    val evaluationVerdict: String = "",
    val recordedWaveform: FloatArray = FloatArray(48)
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is MicTestResult) return false
        if (durationSeconds != other.durationSeconds) return false
        if (rawRmsDb != other.rawRmsDb) return false
        if (boostedRmsDb != other.boostedRmsDb) return false
        if (peakDb != other.peakDb) return false
        if (noiseFloorDb != other.noiseFloorDb) return false
        if (snrDb != other.snrDb) return false
        if (clarityScore != other.clarityScore) return false
        if (isClippingDetected != other.isClippingDetected) return false
        if (activeHardwareName != other.activeHardwareName) return false
        if (evaluationVerdict != other.evaluationVerdict) return false
        return recordedWaveform.contentEquals(other.recordedWaveform)
    }

    override fun hashCode(): Int {
        var result = durationSeconds.hashCode()
        result = 31 * result + rawRmsDb.hashCode()
        result = 31 * result + boostedRmsDb.hashCode()
        result = 31 * result + peakDb.hashCode()
        result = 31 * result + noiseFloorDb.hashCode()
        result = 31 * result + snrDb.hashCode()
        result = 31 * result + clarityScore
        result = 31 * result + isClippingDetected.hashCode()
        result = 31 * result + activeHardwareName.hashCode()
        result = 31 * result + evaluationVerdict.hashCode()
        result = 31 * result + recordedWaveform.contentHashCode()
        return result
    }
}

