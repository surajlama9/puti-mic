package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.Speaker
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AudioRoute
import com.example.data.BoostMode
import com.example.ui.components.AudioConsoleControls
import com.example.ui.components.AudioVisualizer
import com.example.ui.components.GainSliderSection
import com.example.ui.components.HighGainWarningDialog
import com.example.ui.components.MicCircleButton
import com.example.ui.components.MicTestSystemBottomSheet
import com.example.ui.components.OverlayPermissionDialog
import com.example.ui.components.PermissionRationaleDialog
import com.example.ui.components.SafetyDisclaimerDialog
import com.example.ui.components.UnifiedMicSelectorCard
import com.example.ui.components.VoiceChatHubBottomSheet
import com.example.ui.components.VuMeter
import com.example.ui.theme.ConsoleBackground
import com.example.ui.theme.ConsoleBorder
import com.example.ui.theme.ConsoleBorderBright
import com.example.ui.theme.ConsoleSurface
import com.example.ui.theme.ConsoleSurfaceElevated
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.MicViewModel

@Composable
fun PutiMicScreen(
    viewModel: MicViewModel,
    onRequestPermission: () -> Unit,
    onDirectGrantPermission: () -> Unit = onRequestPermission,
    onOpenAppSettings: () -> Unit = {}
) {
    val context = LocalContext.current
    val isLive by viewModel.isLiveRunning.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val audioLevels by viewModel.audioLevels.collectAsState()
    val currentRoute by viewModel.currentRoute.collectAsState()
    val availableRoutes by viewModel.availableRoutes.collectAsState()
    val currentBoostMode by viewModel.currentBoostMode.collectAsState()
    val currentVoiceProfile by viewModel.currentVoiceProfile.collectAsState()
    val isOverlayActive by viewModel.isOverlayActive.collectAsState()
    val showVoiceChatHub by viewModel.showVoiceChatHub.collectAsState()
    val showOverlayPermissionDialog by viewModel.showOverlayPermissionDialog.collectAsState()
    val warningMode by viewModel.warningTargetMode.collectAsState()
    val showDisclaimer by viewModel.showDisclaimerDialog.collectAsState()
    val showPermissionRationale by viewModel.showPermissionRationale.collectAsState()
    val isPermanentlyDenied by viewModel.isPermanentlyDenied.collectAsState()
    val hasPermission by viewModel.hasPermission.collectAsState()

    // Hardware microphone state
    val availableMicInputs by viewModel.availableMicInputs.collectAsState()
    val activeMicStatus by viewModel.activeMicStatus.collectAsState()
    val selectedMicType by viewModel.selectedMicType.collectAsState()

    // Mic Test System & Voice Listening state
    val showMicTestModal by viewModel.showMicTestModal.collectAsState()
    val testState by viewModel.testState.collectAsState()
    val recordingProgress by viewModel.recordingProgress.collectAsState()
    val playbackProgress by viewModel.playbackProgress.collectAsState()
    val latestTestResult by viewModel.latestTestResult.collectAsState()
    val liveLoopbackLevels by viewModel.liveLoopbackLevels.collectAsState()
    val isPlayingBoosted by viewModel.isPlayingBoosted.collectAsState()

    var showRouteMenu by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = ConsoleBackground,
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("puti_mic_screen")
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Spacer(modifier = Modifier.height(2.dp))

            // 1. Top Bar / Brand Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(ConsoleSurface)
                    .border(1.dp, ConsoleBorder, RoundedCornerShape(16.dp))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Logo & Tagline
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    listOf(NeonCyan, ElectricViolet, NeonPink)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = "Puti Mic Logo",
                            tint = Color(0xFF050811),
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Column {
                        Text(
                            text = "PUTI MIC",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 2.sp,
                            color = NeonCyan,
                            modifier = Modifier.testTag("app_title")
                        )
                        Text(
                            text = "Boost Your Voice • Voice Chat Ready",
                            fontSize = 9.sp,
                            color = TextSecondary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // Audio Output Route Pill
                Box {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(ConsoleSurfaceElevated)
                            .border(1.dp, ConsoleBorderBright, RoundedCornerShape(12.dp))
                            .clickable { showRouteMenu = true }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("audio_route_pill"),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val routeIcon = when (currentRoute) {
                            AudioRoute.SPEAKER -> Icons.Default.Speaker
                            AudioRoute.EARPIECE -> Icons.Default.PhoneInTalk
                            AudioRoute.WIRED_HEADSET -> Icons.Default.Headphones
                            AudioRoute.BLUETOOTH -> Icons.Default.Bluetooth
                        }

                        Icon(
                            imageVector = routeIcon,
                            contentDescription = "Route Icon",
                            tint = NeonCyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = currentRoute.displayName.split(" ").first(),
                            color = TextPrimary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    DropdownMenu(
                        expanded = showRouteMenu,
                        onDismissRequest = { showRouteMenu = false },
                        modifier = Modifier
                            .background(ConsoleSurfaceElevated)
                            .border(1.dp, ConsoleBorderBright, RoundedCornerShape(8.dp))
                    ) {
                        availableRoutes.forEach { route ->
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        val icon = when (route) {
                                            AudioRoute.SPEAKER -> Icons.Default.Speaker
                                            AudioRoute.EARPIECE -> Icons.Default.PhoneInTalk
                                            AudioRoute.WIRED_HEADSET -> Icons.Default.Headphones
                                            AudioRoute.BLUETOOTH -> Icons.Default.Bluetooth
                                        }
                                        Icon(
                                            imageVector = icon,
                                            contentDescription = null,
                                            tint = if (route == currentRoute) NeonCyan else TextSecondary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            text = route.displayName,
                                            color = if (route == currentRoute) NeonCyan else TextPrimary,
                                            fontWeight = if (route == currentRoute) FontWeight.Bold else FontWeight.Normal,
                                            fontSize = 12.sp
                                        )
                                    }
                                },
                                onClick = {
                                    viewModel.setAudioRoute(route)
                                    showRouteMenu = false
                                }
                            )
                        }
                    }
                }
            }

            // 2. All-In-One Unified Hardware Microphone Input Selection Card
            UnifiedMicSelectorCard(
                selectedMicType = selectedMicType,
                activeMicStatus = activeMicStatus,
                availableMicInputs = availableMicInputs,
                onSelectMicType = { viewModel.setHardwareMicType(it) }
            )

            // Mic Test & Voice Audition Quick Action Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                ElectricViolet.copy(alpha = 0.25f),
                                NeonCyan.copy(alpha = 0.25f)
                            )
                        )
                    )
                    .border(
                        1.dp,
                        Brush.horizontalGradient(listOf(ElectricViolet, NeonCyan)),
                        RoundedCornerShape(12.dp)
                    )
                    .clickable { viewModel.openMicTestModal() }
                    .padding(horizontal = 14.dp, vertical = 10.dp)
                    .testTag("main_open_mic_test_bar"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(ElectricViolet),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Hearing,
                            contentDescription = null,
                            tint = Color(0xFF030712),
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    Column {
                        Text(
                            text = "MIC TEST • LISTEN TO VOICE",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp,
                            color = TextPrimary
                        )
                        Text(
                            text = "Record 5s sample & listen to boosted voice playback",
                            fontSize = 9.5.sp,
                            color = NeonCyan
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(NeonCyan)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "TEST NOW",
                        color = Color(0xFF030712),
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            // Permission Request Banner (if not granted yet)
            if (!hasPermission) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(NeonPink.copy(alpha = 0.15f))
                        .border(1.dp, NeonPink.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .clickable { onRequestPermission() }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = null,
                            tint = NeonPink,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "Microphone permission is required to amplify audio. Tap to allow.",
                            color = TextPrimary,
                            fontSize = 11.sp
                        )
                    }
                    Text(
                        text = "ALLOW",
                        color = NeonPink,
                        fontWeight = FontWeight.Black,
                        fontSize = 11.sp
                    )
                }
            }

            // 3. Central Circular Microphone Button
            MicCircleButton(
                isLive = isLive,
                isMuted = settings.isMuted,
                outputPeak = audioLevels.outputPeak,
                boostMode = currentBoostMode,
                onClick = {
                    if (!hasPermission) {
                        onRequestPermission()
                    } else {
                        viewModel.toggleMic()
                    }
                }
            )

            // 4. Live Spectrum & Waveform Visualizer
            AudioVisualizer(
                isLive = isLive,
                isMuted = settings.isMuted,
                waveform = audioLevels.waveform,
                frequencyBands = audioLevels.frequencyBands
            )

            // 5. Dual VU Level Meters
            VuMeter(
                inputDb = audioLevels.inputRmsDb,
                outputDb = audioLevels.outputRmsDb,
                isClipping = audioLevels.isClipping,
                isLive = isLive,
                isMuted = settings.isMuted
            )

            // 6. Huge Gain Slider Section (100% to 10,000%)
            GainSliderSection(
                boostPercentage = settings.boostPercentage,
                activeMode = currentBoostMode,
                onPercentageChange = { viewModel.setBoostPercentage(it) },
                onSelectMode = { viewModel.selectBoostMode(it) },
                onDisclaimerClick = { viewModel.openDisclaimerDialog() }
            )

            // 7. Audio Console Controls, Voice Chat Companion & DSP Enhancer
            AudioConsoleControls(
                isLive = isLive,
                settings = settings,
                currentProfile = currentVoiceProfile,
                isOverlayActive = isOverlayActive,
                onToggleLive = {
                    if (!hasPermission) {
                        onRequestPermission()
                    } else {
                        viewModel.toggleMic()
                    }
                },
                onToggleMute = { viewModel.toggleMute() },
                onToggleSpeakerBoost = { viewModel.toggleSpeakerBoost() },
                onEmergencyReset = { viewModel.emergencyReset() },
                onUpdateDsp = { viewModel.updateDsp(it) },
                onOpenVoiceChatHub = { viewModel.openVoiceChatHub() },
                onOpenMicTest = { viewModel.openMicTestModal() },
                onToggleOverlay = { viewModel.toggleFloatingOverlay(context) }
            )

            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    // Microphone Test & Voice Listening System Bottom Sheet
    if (showMicTestModal) {
        MicTestSystemBottomSheet(
            settings = settings,
            testState = testState,
            recordingProgress = recordingProgress,
            playbackProgress = playbackProgress,
            latestResult = latestTestResult,
            liveLoopbackLevels = liveLoopbackLevels,
            isPlayingBoosted = isPlayingBoosted,
            activeMicStatus = activeMicStatus,
            onStartVoiceRecordTest = { duration -> viewModel.startVoiceRecordTest(duration) },
            onPlayVoiceTest = { boosted -> viewModel.playVoiceTest(boosted) },
            onStopVoiceTestPlayback = { viewModel.stopVoiceTestPlayback() },
            onToggleLiveLoopback = { viewModel.toggleLiveLoopbackMonitor() },
            onSetBoostPercentage = { pct -> viewModel.setBoostPercentage(pct) },
            onDismiss = { viewModel.dismissMicTestModal() }
        )
    }

    // Voice Chat Hub Bottom Sheet
    if (showVoiceChatHub) {
        VoiceChatHubBottomSheet(
            settings = settings,
            currentProfile = currentVoiceProfile,
            isOverlayActive = isOverlayActive,
            availableMicInputs = availableMicInputs,
            selectedMicType = selectedMicType,
            onSelectMicType = { viewModel.setHardwareMicType(it) },
            onSelectProfile = { viewModel.applyVoiceChatProfile(it) },
            onSelectInputSource = { viewModel.setAudioInputSource(it) },
            onSelectFocusPolicy = { viewModel.setAudioFocusPolicy(it) },
            onToggleFloatingOverlay = { viewModel.toggleFloatingOverlay(context) },
            onLaunchApp = { packageName -> viewModel.launchVoiceApp(context, packageName) },
            onDismiss = { viewModel.dismissVoiceChatHub() }
        )
    }

    // Draw over apps overlay permission dialog
    if (showOverlayPermissionDialog) {
        OverlayPermissionDialog(
            onDismiss = { viewModel.dismissOverlayPermissionDialog() }
        )
    }

    // Safety and Educational Dialogs
    if (showDisclaimer) {
        SafetyDisclaimerDialog(onDismiss = { viewModel.dismissDisclaimerDialog() })
    }

    if (showPermissionRationale) {
        PermissionRationaleDialog(
            isPermanentlyDenied = isPermanentlyDenied,
            onGrantClick = {
                viewModel.dismissRationale()
                onDirectGrantPermission()
            },
            onOpenSettingsClick = {
                viewModel.dismissRationale()
                onOpenAppSettings()
            },
            onDismiss = {
                viewModel.dismissRationale()
            }
        )
    }

    warningMode?.let { mode ->
        HighGainWarningDialog(
            targetMode = mode,
            onConfirm = { viewModel.confirmWarningMode() },
            onDismiss = { viewModel.dismissWarningDialog() }
        )
    }
}
