package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BoostMode
import com.example.ui.theme.ConsoleBackground
import com.example.ui.theme.ConsoleSurface
import com.example.ui.theme.ConsoleSurfaceElevated
import com.example.ui.theme.DangerRed
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanGlow
import com.example.ui.theme.NeonPink
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.WarningYellow

@Composable
fun MicCircleButton(
    isLive: Boolean,
    isMuted: Boolean,
    outputPeak: Float,
    boostMode: BoostMode,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "mic_pulse")
    val idlePulse by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "idle_pulse"
    )

    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "aura_rotation"
    )

    val dynamicAudioScale by animateFloatAsState(
        targetValue = if (isLive && !isMuted) (1.0f + outputPeak * 0.18f) else 1.0f,
        animationSpec = tween(60),
        label = "audio_scale"
    )

    val effectiveScale = if (isLive) dynamicAudioScale else idlePulse

    val ringColor by animateColorAsState(
        targetValue = when {
            !isLive -> NeonCyan.copy(alpha = 0.35f)
            isMuted -> WarningYellow
            boostMode == BoostMode.EXTREME -> FieryOrangeColor()
            boostMode == BoostMode.PUTI_MAX -> NeonPink
            else -> NeonCyan
        },
        animationSpec = tween(300),
        label = "ring_color"
    )

    val coreButtonBrush = if (isLive) {
        if (isMuted) {
            Brush.radialGradient(listOf(Color(0xFF332005), Color(0xFF140D02)))
        } else {
            Brush.radialGradient(
                listOf(
                    boostMode.accentColor.copy(alpha = 0.25f),
                    ConsoleSurfaceElevated,
                    ConsoleBackground
                )
            )
        }
    } else {
        Brush.radialGradient(
            listOf(
                ConsoleSurfaceElevated,
                ConsoleSurface,
                ConsoleBackground
            )
        )
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(220.dp)
            .testTag("mic_center_button_container")
    ) {
        // Outer glowing pulse ring
        Box(
            modifier = Modifier
                .size(210.dp)
                .scale(effectiveScale)
                .drawBehind {
                    drawCircle(
                        color = ringColor.copy(alpha = if (isLive) 0.25f else 0.08f),
                        radius = size.minDimension / 2
                    )
                }
        )

        // Middle aura ring
        Box(
            modifier = Modifier
                .size(175.dp)
                .border(
                    width = if (isLive) 2.5.dp else 1.dp,
                    brush = Brush.sweepGradient(
                        listOf(
                            ringColor,
                            ringColor.copy(alpha = 0.2f),
                            ElectricViolet,
                            ringColor
                        )
                    ),
                    shape = CircleShape
                )
        )

        // Core interactive button
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(150.dp)
                .shadow(
                    elevation = if (isLive) 16.dp else 6.dp,
                    shape = CircleShape,
                    ambientColor = ringColor,
                    spotColor = ringColor
                )
                .clip(CircleShape)
                .background(coreButtonBrush)
                .border(
                    width = 2.dp,
                    color = if (isLive) ringColor else ConsoleSurfaceElevated,
                    shape = CircleShape
                )
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(bounded = true, color = ringColor),
                    onClick = onClick
                )
                .testTag("main_mic_button")
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = when {
                        !isLive -> Icons.Default.Mic
                        isMuted -> Icons.Default.VolumeOff
                        else -> Icons.Default.Mic
                    },
                    contentDescription = if (isLive) "Stop Microphone" else "Start Microphone",
                    tint = when {
                        !isLive -> TextMuted
                        isMuted -> WarningYellow
                        else -> ringColor
                    },
                    modifier = Modifier.size(54.dp)
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = when {
                        !isLive -> "TAP TO START"
                        isMuted -> "MUTED"
                        else -> "LIVE MIC"
                    },
                    color = when {
                        !isLive -> TextMuted
                        isMuted -> WarningYellow
                        else -> TextPrimary
                    },
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
        }
    }
}

@Composable
private fun FieryOrangeColor(): Color = Color(0xFFFF6D00)
