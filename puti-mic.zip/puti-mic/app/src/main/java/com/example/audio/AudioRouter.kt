package com.example.audio

import android.bluetooth.BluetoothHeadset
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.example.data.AudioRoute
import com.example.data.HardwareMicType
import com.example.data.MicDeviceStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AudioRouter(private val context: Context) {
    private val TAG = "AudioRouter"
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val mainHandler = Handler(Looper.getMainLooper())

    private val _currentRoute = MutableStateFlow(AudioRoute.SPEAKER)
    val currentRoute: StateFlow<AudioRoute> = _currentRoute.asStateFlow()

    private val _availableRoutes = MutableStateFlow<List<AudioRoute>>(listOf(AudioRoute.SPEAKER))
    val availableRoutes: StateFlow<List<AudioRoute>> = _availableRoutes.asStateFlow()

    private val _selectedMicType = MutableStateFlow(HardwareMicType.AUTO)
    val selectedMicType: StateFlow<HardwareMicType> = _selectedMicType.asStateFlow()

    private val _availableMicInputs = MutableStateFlow<List<MicDeviceStatus>>(emptyList())
    val availableMicInputs: StateFlow<List<MicDeviceStatus>> = _availableMicInputs.asStateFlow()

    private val _activeMicStatus = MutableStateFlow(
        MicDeviceStatus(
            type = HardwareMicType.PHONE_MIC,
            name = "Built-in Microphone",
            isConnected = true,
            isActive = true,
            details = "Internal bottom/front hardware mic"
        )
    )
    val activeMicStatus: StateFlow<MicDeviceStatus> = _activeMicStatus.asStateFlow()

    private var hardwareBroadcastReceiver: BroadcastReceiver? = null
    private var audioDeviceCallback: AudioDeviceCallback? = null

    init {
        detectAudioDevices()
        registerHardwareListeners()
    }

    fun setHardwareMicType(type: HardwareMicType) {
        _selectedMicType.value = type
        applyMicRouting(type)
        detectAudioDevices()
    }

    fun detectAudioDevices() {
        // Output routes detection
        val routes = mutableListOf<AudioRoute>()
        routes.add(AudioRoute.SPEAKER)
        routes.add(AudioRoute.EARPIECE)

        var hasHeadsetOut = false
        var hasBluetoothOut = false
        var hasBluetoothMic = false
        var hasWiredMic = false
        var btDeviceName = "Bluetooth Headset"
        var wiredDeviceName = "Wired Headset Mic"
        var builtInMicName = "Phone Built-in Mic"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val outputDevices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            for (device in outputDevices) {
                when (device.type) {
                    AudioDeviceInfo.TYPE_WIRED_HEADSET,
                    AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
                    AudioDeviceInfo.TYPE_USB_HEADSET,
                    AudioDeviceInfo.TYPE_USB_DEVICE -> hasHeadsetOut = true
                    AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
                    AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> {
                        hasBluetoothOut = true
                        if (device.productName.isNotEmpty()) {
                            btDeviceName = device.productName.toString()
                        }
                    }
                }
            }

            val inputDevices = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS)
            for (device in inputDevices) {
                when (device.type) {
                    AudioDeviceInfo.TYPE_BUILTIN_MIC -> {
                        if (device.productName.isNotEmpty()) {
                            builtInMicName = device.productName.toString()
                        }
                    }
                    AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> {
                        hasBluetoothMic = true
                        if (device.productName.isNotEmpty()) {
                            btDeviceName = device.productName.toString()
                        }
                    }
                    AudioDeviceInfo.TYPE_WIRED_HEADSET,
                    AudioDeviceInfo.TYPE_USB_HEADSET,
                    AudioDeviceInfo.TYPE_USB_DEVICE -> {
                        hasWiredMic = true
                        if (device.productName.isNotEmpty()) {
                            wiredDeviceName = device.productName.toString()
                        }
                    }
                }
                // Handle BLE Headset on API 31+
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    if (device.type == AudioDeviceInfo.TYPE_BLE_HEADSET) {
                        hasBluetoothMic = true
                        if (device.productName.isNotEmpty()) {
                            btDeviceName = device.productName.toString()
                        }
                    }
                }
            }

            if (hasHeadsetOut) routes.add(AudioRoute.WIRED_HEADSET)
            if (hasBluetoothOut) routes.add(AudioRoute.BLUETOOTH)
        } else {
            @Suppress("DEPRECATION")
            if (audioManager.isWiredHeadsetOn) {
                routes.add(AudioRoute.WIRED_HEADSET)
                hasWiredMic = true
            }
            @Suppress("DEPRECATION")
            if (audioManager.isBluetoothA2dpOn || audioManager.isBluetoothScoOn) {
                routes.add(AudioRoute.BLUETOOTH)
                hasBluetoothMic = true
            }
        }
        _availableRoutes.value = routes

        // Build list of Input Mic statuses (Device, Bluetooth, Wired, Auto)
        val selected = _selectedMicType.value
        val autoResolvedType = when {
            hasBluetoothMic -> HardwareMicType.BLUETOOTH_MIC
            hasWiredMic -> HardwareMicType.WIRED_MIC
            else -> HardwareMicType.PHONE_MIC
        }

        val activeType = if (selected == HardwareMicType.AUTO) autoResolvedType else selected

        val micStatuses = listOf(
            MicDeviceStatus(
                type = HardwareMicType.AUTO,
                name = "All-In-One Auto Smart Mic",
                isConnected = true,
                isActive = selected == HardwareMicType.AUTO,
                details = when (autoResolvedType) {
                    HardwareMicType.BLUETOOTH_MIC -> "Auto-routed to $btDeviceName (Active)"
                    HardwareMicType.WIRED_MIC -> "Auto-routed to $wiredDeviceName (Active)"
                    else -> "Auto-routed to Built-in Mic (Active)"
                }
            ),
            MicDeviceStatus(
                type = HardwareMicType.PHONE_MIC,
                name = builtInMicName,
                isConnected = true,
                isActive = activeType == HardwareMicType.PHONE_MIC,
                details = "Internal bottom / front microphone array"
            ),
            MicDeviceStatus(
                type = HardwareMicType.BLUETOOTH_MIC,
                name = btDeviceName,
                isConnected = hasBluetoothMic,
                isActive = activeType == HardwareMicType.BLUETOOTH_MIC,
                details = if (hasBluetoothMic) "Wireless Bluetooth SCO / BLE mic ready" else "No Bluetooth headset connected"
            ),
            MicDeviceStatus(
                type = HardwareMicType.WIRED_MIC,
                name = wiredDeviceName,
                isConnected = hasWiredMic,
                isActive = activeType == HardwareMicType.WIRED_MIC,
                details = if (hasWiredMic) "3.5mm TRRS / USB-C mic plugged in" else "No wired headset or USB mic detected"
            )
        )

        _availableMicInputs.value = micStatuses

        // Update active mic status
        _activeMicStatus.value = micStatuses.find { it.type == activeType }
            ?: micStatuses.first { it.type == HardwareMicType.PHONE_MIC }
    }

    fun applyMicRouting(type: HardwareMicType) {
        try {
            when (type) {
                HardwareMicType.AUTO -> {
                    // If bluetooth is connected, enable SCO, else if wired headset, normal mode
                    val hasBt = _availableMicInputs.value.find { it.type == HardwareMicType.BLUETOOTH_MIC }?.isConnected == true
                    if (hasBt) {
                        enableBluetoothSco()
                    } else {
                        disableBluetoothSco()
                    }
                }
                HardwareMicType.BLUETOOTH_MIC -> {
                    enableBluetoothSco()
                }
                HardwareMicType.PHONE_MIC,
                HardwareMicType.WIRED_MIC -> {
                    disableBluetoothSco()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed applying mic routing for $type: ${e.message}")
        }
    }

    private fun enableBluetoothSco() {
        try {
            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
            if (!audioManager.isBluetoothScoOn) {
                audioManager.startBluetoothSco()
                audioManager.isBluetoothScoOn = true
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val inputDevices = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS)
                val btDevice = inputDevices.find {
                    it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO || it.type == AudioDeviceInfo.TYPE_BLE_HEADSET
                }
                if (btDevice != null) {
                    audioManager.setCommunicationDevice(btDevice)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "enableBluetoothSco error: ${e.message}")
        }
    }

    private fun disableBluetoothSco() {
        try {
            if (audioManager.isBluetoothScoOn) {
                audioManager.stopBluetoothSco()
                audioManager.isBluetoothScoOn = false
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                audioManager.clearCommunicationDevice()
            }
        } catch (e: Exception) {
            Log.w(TAG, "disableBluetoothSco error: ${e.message}")
        }
    }

    fun getPreferredInputDevice(type: HardwareMicType): AudioDeviceInfo? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return null

        val inputDevices = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS)
        return when (type) {
            HardwareMicType.PHONE_MIC -> {
                inputDevices.find { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }
            }
            HardwareMicType.BLUETOOTH_MIC -> {
                inputDevices.find {
                    it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                    (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && it.type == AudioDeviceInfo.TYPE_BLE_HEADSET)
                }
            }
            HardwareMicType.WIRED_MIC -> {
                inputDevices.find {
                    it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                    it.type == AudioDeviceInfo.TYPE_USB_HEADSET ||
                    it.type == AudioDeviceInfo.TYPE_USB_DEVICE
                }
            }
            HardwareMicType.AUTO -> {
                // Auto preference order: Bluetooth -> Wired -> Built-in
                inputDevices.find {
                    it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                    (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && it.type == AudioDeviceInfo.TYPE_BLE_HEADSET)
                } ?: inputDevices.find {
                    it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                    it.type == AudioDeviceInfo.TYPE_USB_HEADSET ||
                    it.type == AudioDeviceInfo.TYPE_USB_DEVICE
                } ?: inputDevices.find {
                    it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC
                }
            }
        }
    }

    private fun registerHardwareListeners() {
        // 1. AudioDeviceCallback on Android 6.0+ (API 23+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            audioDeviceCallback = object : AudioDeviceCallback() {
                override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
                    mainHandler.post {
                        detectAudioDevices()
                        applyMicRouting(_selectedMicType.value)
                    }
                }

                override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) {
                    mainHandler.post {
                        detectAudioDevices()
                        applyMicRouting(_selectedMicType.value)
                    }
                }
            }
            audioManager.registerAudioDeviceCallback(audioDeviceCallback, mainHandler)
        }

        // 2. BroadcastReceiver for Headset plug and Bluetooth events
        hardwareBroadcastReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                mainHandler.post {
                    detectAudioDevices()
                    applyMicRouting(_selectedMicType.value)
                }
            }
        }

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_HEADSET_PLUG)
            addAction(AudioManager.ACTION_AUDIO_BECOMING_NOISY)
            addAction(BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED)
            addAction(BluetoothHeadset.ACTION_AUDIO_STATE_CHANGED)
            addAction(AudioManager.ACTION_SCO_AUDIO_STATE_UPDATED)
        }
        try {
            context.registerReceiver(hardwareBroadcastReceiver, filter)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to register hardwareBroadcastReceiver: ${e.message}")
        }
    }

    fun setRoute(route: AudioRoute) {
        _currentRoute.value = route
        try {
            when (route) {
                AudioRoute.SPEAKER -> {
                    audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
                    audioManager.isSpeakerphoneOn = true
                    if (_selectedMicType.value != HardwareMicType.BLUETOOTH_MIC) {
                        disableBluetoothSco()
                    }
                }
                AudioRoute.EARPIECE -> {
                    audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
                    audioManager.isSpeakerphoneOn = false
                    if (_selectedMicType.value != HardwareMicType.BLUETOOTH_MIC) {
                        disableBluetoothSco()
                    }
                }
                AudioRoute.WIRED_HEADSET -> {
                    audioManager.mode = AudioManager.MODE_NORMAL
                    audioManager.isSpeakerphoneOn = false
                }
                AudioRoute.BLUETOOTH -> {
                    audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
                    enableBluetoothSco()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error setting audio route: ${e.message}")
        }
    }

    fun release() {
        try {
            hardwareBroadcastReceiver?.let { context.unregisterReceiver(it) }
        } catch (_: Exception) {}
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                audioDeviceCallback?.let { audioManager.unregisterAudioDeviceCallback(it) }
            }
        } catch (_: Exception) {}
        try {
            disableBluetoothSco()
            audioManager.mode = AudioManager.MODE_NORMAL
        } catch (_: Exception) {}
    }
}
